package com.cts.csap.vo;


import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class SocialAccount implements Serializable{

	@Id
	private String userId;
	private String socialUrl;
	private String password;
	 
	public SocialAccount() {
	}
	
	public SocialAccount(String socialUrl, String userId, String password) {
		super();
		this.socialUrl = socialUrl;
		this.userId = userId;
		this.password = password;
	}
	
	public String getSocialUrl() {
		return socialUrl;
	}
	public void setSocialUrl(String socialUrl) {
		this.socialUrl = socialUrl;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "SocialAccount [socialUrl=" + socialUrl
				+ ", userId=" + userId + ", password=" + password + "]";
	}
	
	
	
}
