package com.cognizant.csap;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;

import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.dvb.ui.DVBTextLayoutManager;
import org.havi.ui.HContainer;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HSceneTemplate;
import org.havi.ui.HState;
import org.havi.ui.HText;
import org.havi.ui.HVisible;
import org.havi.ui.event.HRcEvent;

public class IntentXlet extends HContainer implements javax.tv.xlet.Xlet {

	private static final long serialVersionUID = 1L;
	
	private HScene hscene;
	private HText initialText = null;
	private HText selectedOfferHtext = null;
	private HText vendorDetailText = null;
	private List vendorOfferList = new ArrayList();
	private List textList = new ArrayList();
	
	private int currentx;
	private int currenty;
	
	private boolean isStarted = false;
	
	private String[] productDetails = null; // category, brand, productName array of length 3

	
	public void destroyXlet(boolean arg0) throws XletStateChangeException {
		try {
			if (isStarted) {
				disposeApplication();
				isStarted = false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	public void initXlet(XletContext arg0) throws XletStateChangeException {
		try {
			currentx = 100;
			currenty = 450;
			initGUI();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	public void pauseXlet() {
		if (isStarted)
			hideApplication();
		
	}

	public void startXlet() throws XletStateChangeException {
		try {
			if (!isStarted) {
				isStarted = true;
			}
			showApplication();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	
	
	private void initGUI() {
		this.setLayout(null);
		this.setSize(640, 480);
		
		HSceneTemplate hst = new HSceneTemplate();
		hst.setPreference(HSceneTemplate.SCENE_SCREEN_DIMENSION, new org.havi.ui.HScreenDimension(1, 1), HSceneTemplate.REQUIRED);
		hst.setPreference(HSceneTemplate.SCENE_SCREEN_LOCATION,	new org.havi.ui.HScreenPoint(0, 0), HSceneTemplate.REQUIRED);

		this.hscene = HSceneFactory.getInstance().getBestScene(hst);

		//this.hscene = HSceneFactory.getInstance().getDefaultHScene();
		//this.hscene.setSize(640, 480);
		
		this.hscene.add(this);
		
		//show initial HText
		Font font1 = new Font("Arial", java.awt.Font.PLAIN, 14);
		DVBTextLayoutManager mgr1 = new org.dvb.ui.DVBTextLayoutManager();
		mgr1.setLineSpace(16);
		mgr1.setHorizontalAlign(
		  org.dvb.ui.DVBTextLayoutManager.HORIZONTAL_CENTER);
		mgr1.setVerticalAlign(
		  org.dvb.ui.DVBTextLayoutManager.VERTICAL_CENTER);

//		StringBuffer messageBuf = new StringBuffer("");
//		messageBuf.append("Offers - ");
//		messageBuf.append(getProductOffer());
//		messageBuf.append(" !! Press 3rd colour button on your remote to register interest, or 2nd colour button to cancel.");
//		initialText = new HText(messageBuf.toString(), 40, 400, 560, 80);
		initialText = new HText(
				"Exciting Offers on " + getProductOffer() + "!!  " + 
						"Press 3rd colour button on your remote to register interest, or 2nd colour button to cancel.", 
				40, 420, 560, 60
				);
		initialText.setForeground(Color.YELLOW);
		initialText.setBackground(Color.BLUE);
		initialText.setBackgroundMode(HVisible.BACKGROUND_FILL);
		initialText.setFont(font1);
		initialText.setTextLayoutManager(mgr1);
		initialText.setVisible(true);
		initialText.setFocusable(true);
		initialText.requestFocus();
		this.hscene.add(initialText);
		this.hscene.validate();
		
		
		
		UserEventRepository ueRepository = new UserEventRepository(" ");
		ueRepository.addAllColourKeys();
		ueRepository.addAllArrowKeys();
		ueRepository.addKey(HRcEvent.VK_ENTER);
		
		EventManager.getInstance().addUserEventListener(
				new UserEventListener() {
					public void userEventReceived(UserEvent userEvent) {
						System.out.println("key pressed = " + userEvent.getCode());
						if (userEvent.getCode() == HRcEvent.VK_COLORED_KEY_2) {
							//register user interest
							try {
								System.out.println("Third color key pressed");
								
								vendorOfferList = registerInterest("cust1", productDetails[1], productDetails[2]);
								System.out.println("in Xlet ====================== ");
								System.out.println("list of vendors n offers= " + vendorOfferList);
								System.out.println("in Xlet ====================== ");
								//remove the original text and display another one.
								initialText.setTextContent("Thanks for your interest.  We will update you with more offers on your mobile/online account.  Press the 2nd color button to dismiss this message.", HState.ALL_STATES);

								//show offer table
								hscene.setVisible(true);
								initGUITable(vendorOfferList);
								//initialText.transferFocus();
								
								
							} catch (Exception e) {
								e.printStackTrace();
								initialText.setTextContent("Service is down. Please try later.", HState.ALL_STATES);
								//message = "Service is Down ..Please try later.";
							}
							repaint(); //TODO is this really required ??
						}
						if (userEvent.getCode() == HRcEvent.VK_COLORED_KEY_1) {
							try {
								System.out.println("Second color key pressed. Terminating");
								initialText.setTextContent("Cancelling.. ", HState.ALL_STATES);
								Thread.sleep(2000);
								hideApplication(); //or should it be disposeApplication ??
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						if (userEvent.getCode() == HRcEvent.VK_COLORED_KEY_3) {
							//show more vendor details
							System.out.println("fourth color key pressed");
							
							//System.out.println("selected vendor htext = " + selectedOfferHtext.getTextContent(HState.NORMAL_STATE));
							int indexOfText = textList.indexOf(selectedOfferHtext);
							VendorOfferOcap selectedVendorOffer = (VendorOfferOcap) vendorOfferList.get(indexOfText);
							
							String vendorDetailStr = "Name = " + selectedVendorOffer.getVendorName();
							vendorDetailStr += ", Offer Type = " + selectedVendorOffer.getOfferType();
							vendorDetailStr += ", Offer = " + selectedVendorOffer.getOffer();
							vendorDetailStr += ", Offer Starts on = " + getFormatted(selectedVendorOffer.getStartDate());
							vendorDetailStr += ", Offer Ends on = " + getFormatted(selectedVendorOffer.getEndDate());
							vendorDetailStr += ", Price = " + selectedVendorOffer.getWorthPrice();
							
							if (vendorDetailText != null) {
								hscene.remove(vendorDetailText);
								vendorDetailText.setVisible(false);
								vendorDetailText.invalidate();
							}
							vendorDetailText = getHText(vendorDetailStr);
							DVBTextLayoutManager vendorDetailLayout = new DVBTextLayoutManager();
							vendorDetailLayout.setLineSpace(12);
							vendorDetailLayout.setHorizontalAlign(
							  org.dvb.ui.DVBTextLayoutManager.HORIZONTAL_START_ALIGN);
							vendorDetailLayout.setVerticalAlign(
							  org.dvb.ui.DVBTextLayoutManager.VERTICAL_CENTER);

							vendorDetailText.setBounds(40, 280, 560, 80);
							vendorDetailText.setTextLayoutManager(vendorDetailLayout);
							//vendorOfferDetailText.setBounds(0, 0, 560, 40);
							vendorDetailText.setBackground(Color.ORANGE);
							vendorDetailText.setForeground(Color.BLUE);
							hscene.add(vendorDetailText);
							hscene.validate();
							hscene.repaint();
						}
					}
				}, ueRepository);
		
	}

	public void paint(Graphics g) {
		g.setColor(java.awt.Color.YELLOW);
		//g.drawString(message, currentx, currenty);
		//g.drawImage(img, x, y, observer);
		super.paint(g);
	}
	
	private void initGUITable(List vendorOfferList) {
		
		int numRows = vendorOfferList.size();
		int numCols = 1;
		
		//container for table header
		HContainer headerContainer = new HContainer();
		headerContainer.setLayout(new GridLayout(1,1));
		headerContainer.setBounds(40, 10, 560, 30);
		String headermessage = "Current offers on " + productDetails[1] + " " + productDetails[2] + 
			" " + productDetails[0] + ".  Check online for more...";
		HText headerText = getHText(headermessage);
		headerText.setFocusable(false);
		headerText.setBackground(Color.YELLOW);
		headerText.setForeground(Color.BLUE);
		
		headerContainer.add(headerText);
		headerContainer.setVisible(true);
		hscene.add(headerContainer);
		
		//container for table
		GridLayout layout = new GridLayout(numRows, numCols);
		HContainer container = new HContainer();
		container.setLayout(layout);
		container.setBounds(40, 40, 560, 240);
		
		for (int i = 0; i < numRows*numCols; i++) {
			String rowContent = getRowContent((VendorOfferOcap)vendorOfferList.get(i));
			HText textcomp = getHText(rowContent);
			textList.add(textcomp);
			container.add(textcomp);
		}
		
		//initialText.setFocusTraversal((HText)textList.get(0), (HText)textList.get(0), (HText)textList.get(0), (HText)textList.get(0));
		
		for (int i = 0; i < numRows*numCols; i += numCols) {

			HText textcomp = (HText)textList.get(i);
			if (i == 0) {
				textcomp.setFocusTraversal(null, (HText)textList.get(i+numCols), null, null);
			}
			else if (i == (numRows-1) * numCols) {
				textcomp.setFocusTraversal((HText)textList.get(i-numCols), null, null, null);
			}
			else {
				textcomp.setFocusTraversal((HText)textList.get(i-numCols), (HText)textList.get(i+numCols), null, null);
			}
		}
		
		//((HText)textList.get(3)).setFocusTraversal(((HText)textList.get(0)), ((HText)textList.get(6)), null, null);
		//((HText)textList.get(3)).transferFocus();
		
		container.setVisible(true);
		hscene.add(container);
		hscene.validate();
		hscene.repaint();
		((HText)textList.get(0)).requestFocus();
		selectedOfferHtext = (HText)textList.get(0);
	}
	
	private String getRowContent(VendorOfferOcap offer) {
		
		String vendorName = offer.getVendorName();
		String offertype = offer.getOfferType();
		String offerName = offer.getOffer();
		java.util.Date startDate = offer.getStartDate();
		java.util.Date endDate = offer.getEndDate();
		float price = offer.getWorthPrice();
		
		String offerStr = "" + vendorName + " provides " + offertype + 
			" till " +getFormatted(endDate) + 
			". Avail " + offerName + "!! Price = " + price;
		
		return offerStr;
	}
	
	public String getFormatted(java.util.Date dt) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yy");
		return sdf.format(dt);
	}

	private HText getHText(String content) {
		int fontsize = 14;
		Font font1 = new Font("Arial", java.awt.Font.PLAIN, fontsize);
		DVBTextLayoutManager mgr1 = new org.dvb.ui.DVBTextLayoutManager();
		mgr1.setLineSpace(fontsize);
		mgr1.setHorizontalAlign(
		  org.dvb.ui.DVBTextLayoutManager.HORIZONTAL_CENTER);
		mgr1.setVerticalAlign(
		  org.dvb.ui.DVBTextLayoutManager.VERTICAL_CENTER);

		final HText text = new HText(content, 10, 0, 560, 40);
		//text.setTextLayoutManager(mgr1);
		text.setFont(font1);
		text.setForeground(Color.YELLOW);
		text.setBackground(new Color(64, 64, 128)); 
		text.setBackgroundMode(HVisible.BACKGROUND_FILL);
		text.setFocusable(true);
		text.addFocusListener( new FocusListener() {
			
			public void focusLost(FocusEvent e) {
				text.setForeground(Color.YELLOW);
			}
			
			public void focusGained(FocusEvent e) {
				selectedOfferHtext = text;
				text.setForeground(new Color(64,192,64));
			}	
		});
		
		// :) four PARMAS are UP, DOWN, LEFT, RIGHT :)
		//stoory is in my code, HTEXTDEMO2... please open it
		
		text.setVisible(true);
		text.validate();
		return text;
		
	}
	
	private void showApplication() {
		this.hscene.show();
		this.hscene.repaint();
	}

	private void hideApplication() {
		System.out.println("hiding the scene");
		this.hscene.setVisible(false);
	}

	private void disposeApplication() {
		hideApplication();
		//HScene tmp = hscene;
		//hscene = null;
		HSceneFactory.getInstance().dispose(hscene);
	}
	
	/** 
	 * Create a product hard coded for now.  Later , we may call a web service 
	 * to get some product details from there.
	 * @return
	 */
	private String getProductOffer() {
		CSAPServiceDelegate delegate = new CSAPServiceDelegate();
		String[] p = delegate.getAd();
		this.productDetails = p;
		return p[1] + " " + p[2] + " " + p[0];  // e.g. Sony Vaio Laptop or Dell Latitude E6400 Laptop
	}
	
	private List registerInterest(String user, String brand, String productName) {
		CSAPServiceDelegate delegate = new CSAPServiceDelegate();
		List vendorOfferOcapList = delegate.registerInterest(user, brand, productName);
		return vendorOfferOcapList;
	}
	

}
