package com.cts.csap.service;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;

import com.cts.csap.vo.CSAPUser;
import com.cts.csap.vo.Product;
import com.cts.csap.vo.Vendor;

@WebService
@SOAPBinding(parameterStyle=ParameterStyle.BARE)
public interface IVendorService {

	Vendor addVendor(Vendor vendor);
	Vendor validateVendor(CSAPUser csapUser);
	void addProduct(Product product);
	Product findProduct(String productCategory, String productBrand, String productName);

}