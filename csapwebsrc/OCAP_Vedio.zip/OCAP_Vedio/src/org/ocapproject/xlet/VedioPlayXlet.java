package org.ocapproject.xlet;


import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Vector;

import javax.media.Player;
import javax.tv.service.SIManager;
import javax.tv.service.Service;
import javax.tv.service.navigation.ServiceFilter;
import javax.tv.service.navigation.ServiceIterator;
import javax.tv.service.navigation.ServiceList;
import javax.tv.service.selection.InsufficientResourcesException;
import javax.tv.service.selection.ServiceContentHandler;
import javax.tv.service.selection.ServiceContext;
import javax.tv.service.selection.ServiceContextEvent;
import javax.tv.service.selection.ServiceContextFactory;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;

import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HSceneTemplate;
import org.ocap.media.S3DConfiguration;
import org.ocap.media.S3DSignalingChangedEvent;
import org.ocap.media.VideoFormatControl;
import org.ocap.net.OcapLocator;
import org.ocap.service.AbstractService;
import org.cablelabs.lib.utils.OcapTuner;
import org.cablelabs.test.autoxlet.AutoXletClient;
import org.cablelabs.test.autoxlet.Driveable;
import org.cablelabs.test.autoxlet.Monitor;
import org.cablelabs.test.autoxlet.Test;
import org.cablelabs.xlet.TuneTest.RepeatTune;
import org.dvb.media.VideoFormatEvent;
import org.dvb.media.VideoFormatListener;
import org.dvb.ui.DVBAlphaComposite;
import org.dvb.ui.DVBColor;
import org.dvb.ui.DVBGraphics;
import org.dvb.ui.UnsupportedDrawingOperationException;

public class VedioPlayXlet extends Component implements Xlet,VideoFormatListener,Driveable,KeyListener {
	
	  private Vector _serviceList;
	  private HScene m_scene;
	  private int _channelIndex = 0;
	  private OcapTuner _tuner;
	  private ServiceContext _serviceContext;
	  //private boolean _useJavaTVChannelMap = true;
	  private AutoXletClient _axc = null;
	  private boolean autoMode = false;
	  private Monitor _repeatTuneCleanupMonitor = null;
	  private Monitor _eventMonitor = null;

	  static final int BANNER_XPOS = 50;
      private static final int BANNER_YPOS = 410;
      private static final int BANNER_SPACE = 15;
      
      private String _channelInfo="Aruna";
      
      boolean _directTune = false;
      int _directTuneSourceID = 0;
      
      private Test _test = null;
      
      private RepeatTune _repeatTune = null;
	  
	public void initXlet(XletContext ctx) throws XletStateChangeException {
		
		System.out.println("VedioPlayXlet : init :Aruna");
		m_scene = HSceneFactory.getInstance().getBestScene(new HSceneTemplate());
        m_scene.setLayout(null);
        this.setBounds(0, 0, 640, 480);
        this.setBackground(Color.blue);
        m_scene.add(this);
        
        _axc = new AutoXletClient(this, ctx);
        if (_axc.isConnected())
        {
           autoMode = true;
        }
        
		buildChannelMapFromJavaTV();
		
		 ServiceContextFactory scf = ServiceContextFactory.getInstance();
	        try
	        {
	            _serviceContext = scf.createServiceContext();
	        }
	        catch (InsufficientResourcesException e1)
	        {
	            throw new XletStateChangeException("TuneTestXlet error creating service context");
	        }

	        _tuner = new OcapTuner(_serviceContext);
	        
	     // AutoXlet related
	        // Setup a monitor that we will use to synchronize completion of the
	        // RepeatTune thread. Timeout is 5 seconds.
	        _repeatTuneCleanupMonitor = new Monitor();
	        _repeatTuneCleanupMonitor.setTimeout(5000);

	        // Setup a monitor that we will be used by the event dispatcher to
	        // sychronize tuning events. Timeout will be set by the event being
	        // dispatched
	        _eventMonitor = new Monitor();
	        
	        setChannelAndTune();
			 m_scene.addKeyListener(this);
		      
	        
	        System.out.println("Aruna : INIT worked");
	}

	public void startXlet() {
		
		  m_scene.show();
	        m_scene.requestFocus();
	}

	public void pauseXlet() {
	}

	public void destroyXlet(boolean arg0) throws XletStateChangeException {

	}
	
	 private boolean buildChannelMapFromJavaTV()
	    {
	        // SIManager will provide us with our list of available services
	        SIManager siManager = SIManager.createInstance();
	        siManager.setPreferredLanguage("eng");

	        // filter all abstract services.
	        ServiceFilter broadcastSvcFilter = new ServiceFilter()
	        {
	            public boolean accept(Service service)
	            {
	                if (service instanceof AbstractService)
	                    return false;
	                else
	                    return true;
	            }

		
	        };
	        ServiceList serviceList = siManager.filterServices(broadcastSvcFilter);

	        // Allocate our service list data structure
	        _serviceList = new Vector(serviceList.size());

	        // Populate our list from services returned by SIManager
	        ServiceIterator sitter = serviceList.createServiceIterator();
	        while (sitter.hasNext())
	        {
	            _serviceList.addElement(sitter.nextService());
	        }
	     // Validate that we have a non-zero-length service list and print
	        // out the list of services
	        if (_serviceList.size() > 0)
	        {
	            System.out.println("Aruna :Discovered the following list of services:");

	            // Print a list of services to the log
	            Enumeration e = _serviceList.elements();
	            while (e.hasMoreElements())
	            {
	                Service service = (Service) (e.nextElement());
	                System.out.println("Aruna :"+ service.getName());
	            }

	            return true;
	        }
	        else
	            return false;
	    }
	 
	 private void setChannelAndTune()
	    {
		 
		 System.out.println("Aruna: entered setChannelAndTune");
	        // Check that we have a non-empty service list and a valid channel index
	        int size = _serviceList.size();
	        if (size == 0)
	        {
	            System.out.println("TuneTest Service list is empty!!!");
	            return;
	        }
	        if (_channelIndex >= size) _channelIndex = 0;

	        System.out.println("TuneTest setChannelAndTune -- channelIndex = " + _channelIndex);

	        Service service = (Service) _serviceList.elementAt(_channelIndex);
	        System.out.println("Aruna: Service Element from ServiceList "+service);
	        System.out.println("Aruna: Service Element name"+service.getName());
	        System.out.println("Aruna: service.getServiceType"+service.getServiceType());     
	        

	        // Hide the channel display box until we've finished tuning
	        setVisible(false);

	        _tuner.tune(service);
	    }
	 
	 public void receiveVideoFormatEvent(VideoFormatEvent anEvent)
	    {
	        System.out.println("receiveVideoFormatEvent: " + anEvent);

	        if (anEvent instanceof S3DSignalingChangedEvent)
	        {
	            S3DSignalingChangedEvent s3dEvent = (S3DSignalingChangedEvent) anEvent;
	            _s3dConfig = s3dEvent.getConfig();
	            int transitionType = s3dEvent.getTransitionType();

	            System.out.println("S3DSignalingChangedEvent: transitionType = " + transitionType + ", s3dConfig = " + _s3dConfig);
	            if (transitionType != 2 && _s3dConfig!= null)
	            {
	                System.out.println("S3DSignalingChangedEvent: S3DConfiguration: formatType = " + _s3dConfig.getFormatType()
	                    + ", dataType = " + _s3dConfig.getDataType());
	            }

	            repaint();
	        }
	    }
	 
	 private S3DConfiguration _s3dConfig = null;

	 public void dispatchEvent(KeyEvent event, boolean useMonitor, int monitorTimeout) throws RemoteException
	    {
	        if (useMonitor)
	        {
	            _eventMonitor.setTimeout(monitorTimeout);

	            synchronized (_eventMonitor)
	            {
	                keyPressed(event);
	                _eventMonitor.waitForReady();
	            }
	        }
	        else
	            keyPressed(event);
	    }

	public void keyPressed(KeyEvent e) {
		 int key = e.getKeyCode();
		 
		
	}

	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public void paint(Graphics g)
    {
        DVBGraphics dvbg = (DVBGraphics) g;

        int xpos = BANNER_XPOS;// fixed x position for text lines
        int yspace = BANNER_SPACE;// space between lines
        int ypos = BANNER_YPOS;// starting y position for text lines

        try
        {
            dvbg.setDVBComposite(DVBAlphaComposite.Src);
        }
        catch (UnsupportedDrawingOperationException e)
        {
           System.out.println("Aruna : Exception in paint : usdc"+e);
            return;
        }

        dvbg.setColor(new DVBColor(0, 0, 0, 0)); // transparent
        dvbg.fillRect(0, 0, 640, 480);
        dvbg.setColor(new DVBColor(40, 40, 40, 220));
        dvbg.fillRect(40, 390, 560, 50); // only transparent where video
                                         // displays
        dvbg.setColor(new DVBColor(255, 255, 255, 255)); // transparent

        // draw single strings
        dvbg.setFont(new Font("SansSerif", Font.BOLD, 16));
        dvbg.setColor(Color.white);
        dvbg.drawString("TuneTest:   ", xpos, ypos);
        ypos += yspace;

        synchronized (this)
        {
            dvbg.drawString(_channelInfo, xpos, ypos);
        }

        // Direct tune info
        if (_directTune)
        {
            dvbg.drawRect(495, 402, 60, 25);
            if (_directTuneSourceID != 0) dvbg.drawString("" + _directTuneSourceID, 501, 420);
        }

      }

	public void receiveServiceContextEvent(ServiceContextEvent event)
    {
       System.out.println("TuneTestXlet Tuning Event received: " + event.toString());

        VideoFormatControl vfc = getVFC(event.getServiceContext());
        if (vfc != null)
        {
            System.out.println("receiveServiceContextEvent: vfc = " + vfc);

            vfc.addVideoFormatListener(this);

            _s3dConfig = vfc.getS3DConfiguration();

            repaint();
        }
        else
        {
            System.out.println("receiveServiceContextEvent: null vfc!");
        }


        boolean success = _tuner.tuneEventHandler(event);

        Service service = null;
        if (_repeatTune == null || !_repeatTune.isRunning()) service = (Service) _serviceList.elementAt(_channelIndex);

        Vector tuneQueue = null;
        if (_repeatTune != null)
        {
            tuneQueue = _repeatTune.getTuneQueue();
        }
        if (tuneQueue != null && tuneQueue.size() > 0)
        {
            service = (Service) tuneQueue.firstElement();
            tuneQueue.removeElement(service);
        }

        if (service == null) success = false;

        _test.assertTrue("Tune Failed", success);
       System.out.println("TuneTestXlet, was tune successful? " + success);
        // A tune has completed (could be success or fail). Notify either of
        // our monitors in case a thread is currently sleeping on them, waiting
        // for a tune to finish
        _repeatTuneCleanupMonitor.notifyReady();
        _eventMonitor.notifyReady();

        synchronized (this)
        {
            if (success)
                _channelInfo = channelInfo((OcapLocator) service.getLocator());
            else
                _channelInfo = channelInfo(null);
        }

        setVisible(true);
        repaint();
    }
	
	String channelInfo(OcapLocator ol)
    {
        String channelInfo = null;

        if (ol == null)
        {
            channelInfo = "CHANNEL SELECT FAILED!";
        }
        else if (ol.getSourceID() == -1)
        {
            channelInfo = "Frequency = " + ol.getFrequency() + ", Program Number = " + ol.getProgramNumber()
                    + ", Modulation Format = " + ol.getModulationFormat();
        }
        else
        {
            channelInfo = "Source ID = 0x" + Integer.toHexString(ol.getSourceID());
        }

        String testType = " (";
        if (_repeatTune != null && _repeatTune.isRunning())
        {
            if (_repeatTune.isRampup())
                testType += "Repeat Tune -- Stepped Timing)";
            else if (_repeatTune.isRandomTiming())
                testType += "Repeat Tune -- Random Timing)";
            else
                testType += "Repeat Tune -- Static Timing)";
        }
        else
            testType += "Normal Tune)";
        return channelInfo + testType;

    }

	 private VideoFormatControl getVFC(ServiceContext sctx)
	    {
	        try
	        {
	            ServiceContentHandler[] handlers = sctx.getServiceContentHandlers();
	            Player player = null;
	            for (int i = 0; i < handlers.length; i++)
	            {
	                if (handlers[i] instanceof Player) 
	                {
	                    player = (Player) handlers[i];
	                }
	            }
	            if (player == null)
	            {
	                System.out.println("Unable to get Player");
	                return null;
	            }

	            VideoFormatControl vfControl = (VideoFormatControl) player.getControl(VideoFormatControl.class.getName());
	            if (vfControl == null)
	            {
	                System.out.println("Unable to get VideoFormatControl");
	                return null;
	            }

	            return vfControl;
	        }
	        catch (Exception ex)
	        {
	            System.out.println("Exception getting Player: " + ex.getMessage());
	            return null;
	        }
	    }

	 

}
