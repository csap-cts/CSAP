package org.ocapproject.xlet;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;

import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HNavigable;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HSceneTemplate;
import org.havi.ui.HText;
import org.havi.ui.event.HRcEvent;

public class HTextButtonDemo2 implements Xlet {
	
	private HScene myScene;
	
	private HText hText = new HText();
		
	//private List<HText> textButtons = new ArrayList<HText>();
	private List textButtons = new ArrayList();

	public void initXlet(XletContext ctx) throws XletStateChangeException {	
		UserEventRepository userEventRepository = new UserEventRepository("HTextDemo Events");
		userEventRepository.addAllArrowKeys();
		userEventRepository.addKey(HRcEvent.VK_ENTER);
		userEventRepository.addAllColourKeys();

		HSceneTemplate hst = new HSceneTemplate();
		hst.setPreference(HSceneTemplate.SCENE_SCREEN_DIMENSION, new org.havi.ui.HScreenDimension(1, 1), HSceneTemplate.REQUIRED);
		hst.setPreference(HSceneTemplate.SCENE_SCREEN_LOCATION,	new org.havi.ui.HScreenPoint(0, 0), HSceneTemplate.REQUIRED);

		myScene = HSceneFactory.getInstance().getBestScene(hst);
		//myScene.setSize(1024, 768);
		
		hText = new HText("PRODUCT DETAILS					DETAILS", 10,  20, 700, 25);
		hText.setForeground(Color.YELLOW);
		hText.setBackground(Color.RED);
		hText.setFont(new Font("Bookman Old Style", Font.BOLD, 15));
		hText.setFocusable(false);
		myScene.add(hText);		

		//List<Offer> offers = new ArrayList<HTextButtonDemo2.Offer>();
		List offers = new ArrayList();
		offers.add(new Offer("000001", "Lenovo-", "Laptop", "10% Off", new Date()));
		offers.add(new Offer("000002", "Dell---", "Laptop", "10% Off", new Date()));
		offers.add(new Offer("000003", "HCL----", "Laptop", "20% Off", new Date()));
		offers.add(new Offer("000004", "Sony---", "Laptop", "20% Off", new Date()));
		offers.add(new Offer("000005", "Toshiba", "Laptop", "40% Off", new Date()));
		offers.add(new Offer("000001", "Lenovo-", "Laptop", "10% Off", new Date()));
		offers.add(new Offer("000002", "Dell---", "Laptop", "10% Off", new Date()));
		offers.add(new Offer("000003", "HCL----", "Laptop", "20% Off", new Date()));
		offers.add(new Offer("000004", "Sony---", "Laptop", "20% Off", new Date()));
		offers.add(new Offer("000005", "Toshiba", "Laptop", "40% Off", new Date()));
		
		int LEFT = 50;
		int ROW_DIFF = 60;
		int WIDTH = 500;
		int HEIGHT = 25;
		
		for (int i=0; i < offers.size(); i++) {
			Offer offer = (Offer)offers.get(i);
			HText button = new HText(getFormattedOfferRow(offer), LEFT,  ROW_DIFF, WIDTH, HEIGHT);
			button.setForeground(Color.WHITE);
			button.setBackground(Color.BLUE);
			button.setFont(new Font("Bookman Old Style", Font.BOLD, 15));
			button.setFocusable(true);
			
			myScene.add(button);
			textButtons.add(button);
			
			ROW_DIFF = ROW_DIFF + 35;
		}
		
		// Set Traversing
		for (int i = 0; i < offers.size(); i++) {
			// Set Traversing
			((HText) textButtons.get(i)).setFocusTraversal(getNVL(i-1,  offers.size()), getNVL(i+1,  offers.size()), null, null);
		}
		
		// Add Header row's traversing
		hText.setFocusTraversal(null, (HNavigable) textButtons.get(0), null, null);
		
		myScene.setVisible(true);
		myScene.requestFocus();
		myScene.setVisible(true);
		myScene.setForeground(Color.YELLOW);
		
		UserEventListener userEventListener = new UserEventListener() {

			public void userEventReceived(UserEvent userEvent) {

				String message = "key pressed: Colored Key Code :: " + userEvent.getType() + " :: " + userEvent.getCode();
				
				System.out.println(message);
				if (userEvent.getType() == HRcEvent.KEY_PRESSED) {
					if (userEvent.getCode() == HRcEvent.VK_UP) {
						System.out.println("UP");
					}
					if (userEvent.getCode() == HRcEvent.VK_DOWN) {
						System.out.println("DOWN");
					}
					if (userEvent.getCode() == HRcEvent.VK_LEFT) {
						System.out.println("LEFT");
					}
					if (userEvent.getCode() == HRcEvent.VK_RIGHT) {
						System.out.println("RIGHT");
					}
					if (userEvent.getCode() == HRcEvent.VK_ENTER) {
						hText.transferFocus();
					}
				}
			}
		};

		EventManager.getInstance().addUserEventListener(userEventListener, userEventRepository);
	}

	private HText getNVL(int i, int size) {
		if(i<0 || i>= size)
		return null;
		
		return (HText) textButtons.get(i);
	}

	private String getFormattedOfferRow(Offer offer) {
		return   offer.getProductName() + " " + offer.getProductDetails() + "  " + offer.getOfferDetails();
	}

	public void startXlet() throws XletStateChangeException {
		myScene.setVisible(true);
	}

	public void pauseXlet() {
	}

	public void destroyXlet(boolean forced) throws XletStateChangeException {
	}
	
	class Offer {
		private String productName;
		private String productDetails;
		private String offerDetails;
		private String offerId;
		private Date offerDate;

		public Offer(String offerId, String productName, String productDetails, String offerDetails, Date offerDate) {
			this.setOfferDetails(offerDetails);
			this.setOfferId(offerId);
			this.setProductDetails(productDetails);
			this.setProductName(productName);
			this.setOfferDate(offerDate);
		}

		public String getOfferId() {
			return offerId;
		}

		public void setOfferId(String offerId) {
			this.offerId = offerId;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String productName) {
			this.productName = productName;
		}

		public String getProductDetails() {
			return productDetails;
		}

		public void setProductDetails(String productDetails) {
			this.productDetails = productDetails;
		}

		public String getOfferDetails() {
			return offerDetails;
		}

		public void setOfferDetails(String offerDetails) {
			this.offerDetails = offerDetails;
		}

		public Date getOfferDate() {
			return offerDate;
		}

		public void setOfferDate(Date offerDate) {
			this.offerDate = offerDate;
		}
	}
}

