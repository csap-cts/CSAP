package com.cts.csap.vo;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class CSAPUser implements Serializable {
	
	@Id
	private String userName;
	private String password;
	private CSAPUserRoles role;
	
	
	
	public CSAPUser(String userName, String password, CSAPUserRoles role) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	
	public CSAPUser() {
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public CSAPUserRoles getRole() {
		return role;
	}
	public void setRole(CSAPUserRoles role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "CSAPUser [userName=" + userName + ", password=" + password
				+ ", role=" + role + "]";
	}
	
	
	
	
	

}
