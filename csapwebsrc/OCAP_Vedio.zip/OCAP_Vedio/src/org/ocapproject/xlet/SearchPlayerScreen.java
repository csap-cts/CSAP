package org.ocapproject.xlet;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.net.URL;
import java.util.ArrayList;

import org.dvb.ui.DVBAlphaComposite;
import org.dvb.ui.DVBGraphics;
import org.dvb.ui.UnsupportedDrawingOperationException;

import sportsstats.com.cts.beans.PlayerData;
import sportsstats.com.cts.model.Storage;
import sportsstats.com.cts.xlet.StatsXlet;

/**
 * 
 * @author bhanuprasad.gamidi@cognizant.com
 * 
 *         Search Player Screen facilitates the User for searching the player
 *         from the two teams playing the Baseball game. It also provides the
 *         user to browse the preditive list of the Players and he has three
 *         Options 1. He can get the PlayerStats of the selected player 2. He
 *         can Go back to home(UserMenu) Screen. 3. He can exit the
 *         Application(Hiding the application).
 * 
 *         In this Screen User has three modes : 1. KeySelection : In this the
 *         focus will be on KeyPad and the User can type the required letter. 2.
 *         PlayerMenu : In this mode focus will be on the Predictive PlayersList
 *         and the user can select the Player from the list 3. UserSelection :
 *         In this mode Focus will be on the UserSelection Tabs and User can
 *         enter his selection from tabs menu.
 * 
 * 
 */

public class SearchPlayerScreen extends Component {

	private static final long serialVersionUID = 1L;

	// Background image
	public Image m_background;

	private static final String IMAGE_PATH = new String(
			"/sportsstats/com/cts/xlet/SportsStatsImages/");

	public boolean capslock = false;

	public int x = 26;

	public int y = 220;

	public ArrayList lastCharList = null;

	public ArrayList lastNumList = null;

	public boolean isNumericKeyPad = false;

	public boolean isSymbolsKeyPad = false;

	public int keyHeight = 24;

	public int keyWidth = 20;

	public Image[] Stats = new Image[2];

	public boolean isTeamSelected = false;

	public String teamName = "";

	public String finalTeamName = "";

	public static ArrayList teamList = new ArrayList();
	static {
		teamList.add("CWS");
		teamList.add("BRS");
	}

	public ArrayList teams = null;

	public String finalPlayerName = "";

	public String[] UserOptions;

	public Image[] homeButtons = new Image[2];

	public Image[] playButtons = new Image[2];

	public Image[] gameButtons = new Image[2];

	// Banner background picture and its location
	private static final String BANNER_PIC_STATS = "/sportsstats/com/cts/xlet/SportsStatsImages/2nd_screen_bg.png";

	private static final Point BANNER_LOC_STATS = new Point(0, 0);

	// Channel info on the banner
	private static final Point BANNER_INFO_LOC = new Point(30, 215);

	public Point KEY_LOC = new Point(28, 240);

	private static final Font BANNER_INFO_FONT = new Font("tiresias",
			Font.PLAIN, 18);

	private static final Color BANNER_INFO_COLOR = new Color(247, 239, 180); // text

	private static final Font BANNER_STATS_TITLE = new Font("tiresias",
			Font.PLAIN, 24);

	private static final String HILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/search_plyr_btn_hghlt.png";

	private static final String UNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/search_plyr_btn.png";

	private static final String HOMEHILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn_over.png";

	private static final String HOMEUNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn.png";

	private static final String GAMEHILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn_over.png";

	private static final String GAMEUNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn.png";

	public String playerName = "";

	public ArrayList predictiveText;

	public boolean blinkcursor = true;

	public boolean fecthplayersnames;

	public boolean changed;

	public int cursorindex = 0;

	public int focusletter = 0;

	public int selectOption;

	public boolean TextMode;

	public boolean editTextMode;

	public boolean UserSelected;

	public boolean keySelection;

	public boolean playermenu;

	public boolean error;

	public String errorMessage = "";

	// public Blinking cursorBlink;

	public boolean selected = false;

	public int preTextindex;

	public int teamIndex;

	public Storage store;

	public SearchPlayerScreen() {
		URL url;

		if (Storage.screens.containsKey("SearchPlayer")) {
			m_background = (Image) Storage.screens.get("SearchPlayer");
		} else {
			url = this.getClass().getResource(BANNER_PIC_STATS);
			m_background = java.awt.Toolkit.getDefaultToolkit().getImage(url);
			Storage.screens.put("SearchPlayer", m_background);
		}

		MediaTracker mt = new MediaTracker(this);
		mt.addImage(m_background, 0);
		// Loading Required button images for Search player Screen
		if (Storage.reqImages.containsKey("SearchPlayerButtons")) {
			playButtons = (Image[]) Storage.reqImages
					.get("SearchPlayerButtons");
			for (int i = 0; i < playButtons.length; i++) {
				mt.addImage(playButtons[i], i + 1);
			}
		} else {
			for (int i = 0; i < playButtons.length; i++) {
				if (i == 0)
					url = this.getClass().getResource(HILIGHTED);
				else
					url = this.getClass().getResource(UNHIGHLITED);
				playButtons[i] = java.awt.Toolkit.getDefaultToolkit().getImage(
						url);
			}
			Storage.reqImages.put("SearchPlayerButtons", playButtons);
		}
		if (Storage.reqImages.containsKey("HomeButtons")) {
			homeButtons = (Image[]) Storage.reqImages.get("HomeButtons");
			for (int i = 0; i < homeButtons.length; i++) {
				mt.addImage(homeButtons[i], i + 3);
			}
		} else {
			for (int i = 0; i < homeButtons.length; i++) {
				if (i == 0)
					url = this.getClass().getResource(HOMEHILIGHTED);
				else
					url = this.getClass().getResource(HOMEUNHIGHLITED);
				homeButtons[i] = java.awt.Toolkit.getDefaultToolkit().getImage(
						url);
			}
			Storage.reqImages.put("HomeButtons", homeButtons);
		}

		if (Storage.reqImages.containsKey("GameButtons")) {
			gameButtons = (Image[]) Storage.reqImages.get("GameButtons");
			for (int i = 0; i < gameButtons.length; i++) {
				mt.addImage(gameButtons[i], i + 5);
			}
		} else {
			for (int i = 0; i < gameButtons.length; i++) {
				if (i == 0)
					url = this.getClass().getResource(GAMEHILIGHTED);
				else
					url = this.getClass().getResource(GAMEUNHIGHLITED);
				gameButtons[i] = java.awt.Toolkit.getDefaultToolkit().getImage(
						url);
				mt.addImage(gameButtons[i], i + 5);

			}
			Storage.reqImages.put("GameButtons", gameButtons);
		}
		lastCharList = new ArrayList();
		lastCharList.add("a");
		lastCharList.add("Caps");
		lastCharList.add(".?123");
		lastNumList = new ArrayList();
		lastNumList.add("-");
		lastNumList.add("#+=");
		lastNumList.add("abc");
		try {
			mt.waitForAll();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		teams = new ArrayList();
		// Set this component's location and size
		// setLocation(BANNER_LOC_STATS);
		/*
		 * setLocation(new Point(0,0)); setSize(m_background.getWidth(this),
		 * m_background.getHeight(this));
		 */
		StatsXlet.m_scene.setBounds(116, 21, 308, 450);
		this.setBounds(0, 0, 308, 450);
		setFont(BANNER_INFO_FONT);
		setForeground(BANNER_INFO_COLOR);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paint(Graphics g) {
		DVBAlphaComposite c = DVBAlphaComposite.getInstance(
				DVBAlphaComposite.SRC_OVER, 0.9f);
		try {
			((DVBGraphics) g).setDVBComposite(c);
		} catch (UnsupportedDrawingOperationException e) {
			e.printStackTrace();
		}
		g.clearRect(0, 0, 308, 450);
		// Draw the banner background
		g.drawImage(m_background, BANNER_LOC_STATS.x, BANNER_LOC_STATS.y, this);
		g.setFont(new Font("tiresias", Font.BOLD, 20));
		g.setColor(Color.white);
		g.drawString("Player Search", BANNER_INFO_LOC.x + 50, 25);
		// starting the Cursor Blinking Thread
		if (fecthplayersnames) {
			store = new Storage();
			fecthplayersnames = false;
			// cursorBlink = new Blinking(this);
			// cursorBlink.start();
		}

		g.setColor(BANNER_INFO_COLOR);

		// Logic to change the Focus on the letter
		if (isNumericKeyPad || isSymbolsKeyPad) {
			if (focusletter == 27 || focusletter == 29) {
				keyWidth = 64;
			} else if (focusletter == 28) {
				keyWidth = 142;
			} else if (focusletter > 19) {
				keyWidth = 36;
			} else {
				keyWidth = 31;
			}
			g.setFont(new Font("tiresias", Font.BOLD, 14));
			for (int i = 0; i < 4; i++) {
				if ((i == 1) || (i == 0)) {
					for (int j = 1; j < 11; j++) {
						// g.setColor(new Color(107, 196, 247));
						g.setColor(new Color(151, 213, 249));
						g.fillRoundRect((KEY_LOC.x + ((j - 1) * 26)),
								(KEY_LOC.y + (i * 28) - 18), 23, keyHeight - 1,
								10, 10);
						g.setColor(Color.black);
						g.drawString(getNumbers(j + (i * 10)).toUpperCase(),
								KEY_LOC.x + ((j - 1) * 27) + 2, KEY_LOC.y
										+ (i * 28));
					}
				} else if (i == 2) {
					for (int j = 1; j < 8; j++) {
						String letter = getNumbers(j + (i * 10)).toUpperCase();
						if (letter.equals("BACK")) {
							g.drawImage(loadImage("keypad_back.png"), KEY_LOC.x
									+ ((j - 1) * 31) + 24, KEY_LOC.y + (i * 28)
									- 18, null);
						} else if (letter.equals("#+=")) {
							g.setColor(new Color(151, 213, 249));
							g.fillRoundRect((KEY_LOC.x + ((j - 1) * 31) + 24),
									(KEY_LOC.y + (i * 28)) - 18, 28,
									keyHeight - 1, 10, 10);
							g.setColor(Color.black);
							g.drawString(letter, KEY_LOC.x + ((j - 1) * 32)
									+ 24, KEY_LOC.y + (i * 28));
						} else {
							g.setColor(new Color(151, 213, 249));
							g.fillRoundRect((KEY_LOC.x + ((j - 1) * 31) + 24),
									(KEY_LOC.y + (i * 28)) - 18, 28,
									keyHeight - 1, 10, 10);
							g.setColor(Color.black);
							g.drawString(letter, KEY_LOC.x + ((j - 1) * 32)
									+ 29, KEY_LOC.y + (i * 28));
						}
					}
				} else {
					for (int j = 1; j < 4; j++) {
						if (j == 1) {
							g.setColor(new Color(151, 213, 249));
							g.fillRoundRect(30, 305, 60, keyHeight - 1, 10, 10);
							g.setColor(Color.black);
							g.drawString(getNumbers(j + (i * 9)).toUpperCase(),
									42, 322);
						} else if (j == 2) {
							g.setColor(new Color(151, 213, 249));
							g
									.fillRoundRect(93, 305, 130, keyHeight - 1,
											10, 10);
							g.setColor(Color.black);
							g.drawString(getNumbers(j + (i * 9)).toUpperCase(),
									137, 322);
						} else {
							g.setColor(new Color(151, 213, 249));
							g
									.fillRoundRect(225, 305, 60, keyHeight - 1,
											10, 10);
							g.setColor(Color.black);
							g.drawString(getNumbers(j + (i * 9)).toUpperCase(),
									236, 322);
						}
					}
				}
				if (keySelection) {
					System.out.println("inside key selection:" + x + y);
					if (focusletter == 26) {
						g.drawImage(loadImage("keypad_back_HL.png"), x, y - 2,
								null);
					} else {
						g.setColor(new Color(247, 239, 180));
						g.fill3DRect(x, y, keyWidth, keyHeight + 2, true);
						g.setColor(Color.black);
						if (focusletter == 28) {
							g.drawString(getNumbers(focusletter + 1)
									.toUpperCase(), x + 50, y + 18);
						} else if (focusletter == 20) {
							g.drawString(getNumbers(focusletter + 1)
									.toUpperCase(), x + 3, y + 18);
						} else {
							g.drawString(getNumbers(focusletter + 1)
									.toUpperCase(), x + 10, y + 18);
						}
					}
				}
			}

		} else {
			if (focusletter == 28 || focusletter == 30) {
				keyWidth = 64;
			} else if (focusletter == 29) {
				keyWidth = 142;
			} else {
				keyWidth = 31;
			}
			g.setFont(new Font("tiresias", Font.BOLD, 14));
			for (int i = 0; i < 4; i++) {
				if ((i == 1)) {
					for (int j = 1; j < 10; j++) {
						g.setColor(new Color(151, 213, 249));
						g.fillRoundRect(((KEY_LOC.x + ((j - 1) * 26)) + 13),
								(KEY_LOC.y + (i * 28) - 18), 23, keyHeight - 1,
								10, 10);
						g.setColor(Color.black);
						g.drawString(getAlphabets(j + (i * 10)).toUpperCase(),
								(KEY_LOC.x + ((j - 1) * 27) + 13), KEY_LOC.y
										+ (i * 28));
					}
				} else if (i == 2) {
					for (int j = 0; j < 9; j++) {
						String letter = getAlphabets(j + (i * 10))
								.toUpperCase();
						if (letter.equals("CAPS")) {
							g.drawImage(loadImage("caps.png"), KEY_LOC.x
									+ ((j - 1) * 25) + 29, KEY_LOC.y + (i * 28)
									- 20, null);
						} else if (letter.equals("BACK")) {
							g.drawImage(loadImage("keypad_back.png"), 250,
									KEY_LOC.y + (i * 28) - 17, null);
						} else {
							g.setColor(new Color(151, 213, 249));
							g.fillRoundRect(
									((KEY_LOC.x + ((j - 1) * 26)) + 39),
									(KEY_LOC.y + (i * 28) - 18), 23,
									keyHeight - 1, 10, 10);
							g.setColor(Color.black);
							g.drawString(getAlphabets(j + (i * 10))
									.toUpperCase(), KEY_LOC.x + ((j - 1) * 27)
									+ 42, KEY_LOC.y + (i * 28));
						}
					}
				} else if (i == 3) {
					for (int j = 1; j < 4; j++) {
						if (j == 1) {
							g.setColor(new Color(151, 213, 249));
							g.fillRoundRect(30, 305, 60, keyHeight - 1, 10, 10);
							g.setColor(Color.black);
							g.drawString(getAlphabets(j + (i * 9) + 1)
									.toUpperCase(), 42, 322);
						} else if (j == 2) {
							g.setColor(new Color(151, 213, 249));
							g
									.fillRoundRect(93, 305, 130, keyHeight - 1,
											10, 10);
							g.setColor(Color.black);
							g.drawString(getAlphabets(j + (i * 9) + 1)
									.toUpperCase(), 137, 322);
						} else {
							g.setColor(new Color(151, 213, 249));
							g
									.fillRoundRect(225, 305, 60, keyHeight - 1,
											10, 10);
							g.setColor(Color.black);
							g.drawString(getAlphabets(j + (i * 9) + 1)
									.toUpperCase(), 236, 322);
						}
					}
				} else {
					for (int j = 1; j < 11; j++) {
						// g.setColor(new Color(107, 196, 247));
						g.setColor(new Color(151, 213, 249));
						g.fillRoundRect((KEY_LOC.x + ((j - 1) * 26)),
								(KEY_LOC.y + (i * 28) - 18), 23, keyHeight - 1,
								10, 10);
						g.setColor(Color.black);
						g.drawString(getAlphabets(j + (i * 12)).toUpperCase(),
								KEY_LOC.x + ((j - 1) * 27), KEY_LOC.y
										+ (i * 28));
					}
				}
				if (keySelection) {
					if (focusletter == 19) {
						g.drawImage(loadImage("caps_HL.png"), x - 5, y - 2,
								null);
					} else if (focusletter == 27) {
						g.drawImage(loadImage("keypad_back_HL.png"), x, y - 2,
								null);
					} else {
						g.setColor(new Color(247, 239, 180));
						g.fill3DRect(x, y, keyWidth, keyHeight + 2, true);
						g.setColor(Color.black);
						if (focusletter == 29) {
							g.drawString(getAlphabets(focusletter + 1)
									.toUpperCase(), x + 50, y + 18);
						} else {
							g.drawString(getAlphabets(focusletter + 1)
									.toUpperCase(), x + 8, y + 18);
						}
					}
				}
			}
		}
		g.drawImage(playButtons[1], BANNER_INFO_LOC.x - 20,
				BANNER_INFO_LOC.y + 190, this);
		g.drawImage(homeButtons[1], BANNER_INFO_LOC.x + 80,
				BANNER_INFO_LOC.y + 185, this);
		g.drawImage(gameButtons[1], BANNER_INFO_LOC.x + 180,
				BANNER_INFO_LOC.y + 185, this);
		if (selectOption == 0) {
			g.drawImage(playButtons[0], BANNER_INFO_LOC.x - 20,
					BANNER_INFO_LOC.y + 190, this);
			g.drawImage(homeButtons[1], BANNER_INFO_LOC.x + 80,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(gameButtons[1], BANNER_INFO_LOC.x + 180,
					BANNER_INFO_LOC.y + 185, this);
		} else if (selectOption == 1) {
			g.drawImage(playButtons[1], BANNER_INFO_LOC.x - 20,
					BANNER_INFO_LOC.y + 190, this);
			g.drawImage(homeButtons[0], BANNER_INFO_LOC.x + 80,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(gameButtons[1], BANNER_INFO_LOC.x + 180,
					BANNER_INFO_LOC.y + 185, this);
		} else if (selectOption == 2) {
			g.drawImage(playButtons[1], BANNER_INFO_LOC.x - 20,
					BANNER_INFO_LOC.y + 190, this);
			g.drawImage(homeButtons[1], BANNER_INFO_LOC.x + 80,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(gameButtons[0], BANNER_INFO_LOC.x + 180,
					BANNER_INFO_LOC.y + 185, this);
		}

		// Displaying the User help text depending on the Mode on the screen
		g.setColor(Color.white);
		g.setFont(new Font("Arial", Font.PLAIN, 13));
		String helpText = null;
		if (isTeamSelected) {
			helpText = "team name";
		} else {
			helpText = "player name";
		}
		if (keySelection) {
			g.drawString("Enter " + helpText + " using Arrow keys & "
					+ "Select button", BANNER_INFO_LOC.x - 23,
					BANNER_INFO_LOC.y + 150);
		} else if (playermenu && selectOption < 0) {
			g.drawString("Press Up and Down to select the " + helpText,
					BANNER_INFO_LOC.x, BANNER_INFO_LOC.y + 150);
		} else {
			g.drawString("To state your selection press Select",
					BANNER_INFO_LOC.x + 10, BANNER_INFO_LOC.y + 150);
		}
		g.setFont(BANNER_STATS_TITLE);

		// Getting the Predictive player list depending on the User entered
		// value
		if (!editTextMode) {
			g.setFont(new Font("Arial", Font.BOLD, 18));
			g.drawString("Player Name", BANNER_INFO_LOC.x - 20,
					BANNER_INFO_LOC.y - 100);
			g.drawString("Team Name", BANNER_INFO_LOC.x + 130,
					BANNER_INFO_LOC.y - 100);
			g.fillRect(BANNER_INFO_LOC.x - 20, BANNER_INFO_LOC.y - 90, 140, 26);
			g
					.fillRect(BANNER_INFO_LOC.x + 130, BANNER_INFO_LOC.y - 90,
							140, 26);
			g.setFont(new Font("Arial", Font.PLAIN, 13));
			// update the Predictive Players list for every change in the
			// UserInput
			if (playerName.length() == 0) {
				if (predictiveText != null)
					predictiveText.clear();
				g.setColor(Color.black);
				blinkCursor(g, blinkcursor);
				if (error) {
					g.setColor(Color.red);
					g.setFont(new Font("Arial", Font.PLAIN, 18));
					g.drawString(errorMessage, BANNER_INFO_LOC.x + 5,
							BANNER_INFO_LOC.y - 15);
				}
			} else {
				if (changed) {
					predictiveText = store
							.getSelectedNamesfromservice(playerName);
					for (int i = 0; i < predictiveText.size(); i++) {
						PlayerData res = (PlayerData) predictiveText.get(i);
						System.out.println(i + 1 + "." + res.getFirstName()
								+ " " + res.getLastName());

					}
					changed = false;
				}
			}
			if (!isTeamSelected) {
				// Displaying the Predictive Players list menu
				int displayX = BANNER_INFO_LOC.x - 15;
				int displayY = BANNER_INFO_LOC.y - 45;
				if (predictiveText != null) {
					if (predictiveText.size() != 0) {
						Image[] playersmenu = new Image[predictiveText.size()];
						URL url2;
						MediaTracker mt = new MediaTracker(this);

						for (int z = 0; z < predictiveText.size(); z++) {
							if (z == 0)
								url2 = this.getClass().getResource(HILIGHTED);
							else
								url2 = this.getClass().getResource(UNHIGHLITED);
							playersmenu[z] = java.awt.Toolkit
									.getDefaultToolkit().getImage(url2);
							mt.addImage(playersmenu[z], 1 + Stats.length + z
									+ 1);
						}

						for (int p = 0; p < predictiveText.size(); p++) {

							PlayerData res = (PlayerData) predictiveText.get(p);

							if (preTextindex - p == 0) {
								g.setColor(Color.black);
								if (playermenu || UserSelected) {
									if (selected) {
										UserSelected = true;
										playermenu = false;
										selected = false;
										isTeamSelected = true;
										keySelection = true;
										cursorindex = 0;
										focusletter = 0;
										x = 26;
										y = 220;
										isSymbolsKeyPad = false;
										isTeamSelected = true;
										repaint();
										finalPlayerName = res.getFirstName()
												+ "," + res.getLastName() + " "
												+ res.getTeam() + " "
												+ res.getPosition();
										g.drawString(res.getFirstName() + ","
												+ res.getLastName() + " "
												+ res.getTeam() + " "
												+ res.getPosition(),
												BANNER_INFO_LOC.x - 18,
												BANNER_INFO_LOC.y - 70);
									} else {
										g.drawString(playerName,
												BANNER_INFO_LOC.x - 18,
												BANNER_INFO_LOC.y - 70);
									}
								}
								int y = this.getFontMetrics(getFont())
										.getAscent();
								g.setColor(Color.white);
								g.drawRect(displayX - 6, displayY + (p * 25)
										- y - 1, 140, 26);
								g.setColor(BANNER_INFO_COLOR);
								g.fillRect(displayX - 5, displayY + (p * 25)
										- y, 140, 25);
								g.setColor(Color.blue);
								g.drawString(res.getFirstName() + ","
										+ res.getLastName() + " "
										+ res.getTeam() + " "
										+ res.getPosition(), displayX - 3,
										displayY + (p * 25));
								if (keySelection) {
									g.setColor(Color.black);
									blinkCursor(g, blinkcursor);
								}

							} else {
								g.setColor(Color.white);
								g.drawString(res.getFirstName() + ","
										+ res.getLastName() + " "
										+ res.getTeam() + " "
										+ res.getPosition(), displayX - 3,
										displayY + (p * 25));
							}
						}
					} else {
						g.setColor(Color.white);
						if (playerName.length() != 0) {
							g.drawString("No Records found", displayX - 3,
									displayY);
							g.setColor(Color.black);
							blinkCursor(g, blinkcursor);
						}
					}
				}
			} else {
				System.out.println("fdssssssssssss" + teamIndex);
				g.setColor(Color.black);
				if (finalPlayerName != null) {
					g.drawString(finalPlayerName, BANNER_INFO_LOC.x - 18,
							BANNER_INFO_LOC.y - 70);
				}
				if (error) {
					g.setColor(Color.red);
					g.setFont(new Font("Arial", Font.PLAIN, 18));
					g.drawString(errorMessage, BANNER_INFO_LOC.x + 5,
							BANNER_INFO_LOC.y - 15);
				}
				if (teamName != null) {
					g.drawString(teamName, BANNER_INFO_LOC.x + 135,
							BANNER_INFO_LOC.y - 70);
					int pointX = BANNER_INFO_LOC.x + 135;
					int pointY = BANNER_INFO_LOC.y - 45;
					int cnt = 0;
					teams.clear();
					for (int i = 0; i < teamList.size(); i++) {
						String name = (String) teamList.get(i);
						if (!teamName.equals("")
								&& name.startsWith(teamName.toUpperCase()
										.trim())) {
							cnt++;
							teams.add(name);
						}
					}
					if (playermenu && selected && teams.size() > 0) {
						g.setColor(Color.black);
						teamName = (String) teams.get(teamIndex);
						finalTeamName = teamName;
						g.drawString(finalTeamName, BANNER_INFO_LOC.x + 135,
								BANNER_INFO_LOC.y - 70);
						teams.clear();
					} else {
						if (keySelection) {
							g.setColor(Color.black);
							blinkCursor(g, blinkcursor);
						}
					}
					if (selectOption < 0) {
						for (int j = 0; j < teams.size(); j++) {
							if (teamIndex == j) {
								g.setColor(BANNER_INFO_COLOR);
								g.fillRect(pointX - 5, pointY + (j * 25) - 18,
										140, 26);
								g.setColor(Color.blue);
								g.drawString((String) teams.get(j), pointX - 3,
										pointY + (j * 25));
							} else {
								g.setColor(Color.white);
								g.drawString((String) teams.get(j), pointX - 3,
										pointY + (j * 25));
							}
						}
						if (!teamName.equals("") && cnt == 0) {
							g.setColor(Color.white);
							g
									.drawString("No Records found", pointX - 3,
											pointY);
							g.setColor(Color.black);
							blinkCursor(g, blinkcursor);
						}
					}

				}
			}
		} else {
			g.setColor(Color.black);
			blinkCursor(g, blinkcursor);
		}
		getToolkit().sync();
	}

	/**
	 * Shows the banner and starts the dismiss timer.
	 * 
	 * @param duration
	 */
	public void show(long duration) {
		setVisible(true);

	}

	/*
	 * This method is used to build up the keyPad letters
	 */
	public String getAlphabets(int x) {
		String res = "";
		switch (x) {
		case 1:
			res = "q";
			break;

		case 2:
			res = "w";
			break;

		case 3:
			res = "e";
			break;

		case 4:
			res = "r";
			break;

		case 5:
			res = "t";
			break;

		case 6:
			res = "y";
			break;

		case 7:
			res = "u";
			break;

		case 8:
			res = "i";
			break;

		case 9:
			res = "o";
			break;

		case 10:
			res = "p";
			break;

		case 11:
			res = "a";
			break;

		case 12:
			res = "s";
			break;

		case 13:
			res = "d";
			break;

		case 14:
			res = "f";
			break;

		case 15:
			res = "g";
			break;

		case 16:
			res = "h";
			break;

		case 17:
			res = "j";
			break;

		case 18:
			res = "k";
			break;

		case 19:
			res = "l";
			break;

		case 20:
			res = "Caps";
			break;

		case 21:
			res = "z";
			break;

		case 22:
			res = "x";
			break;
		case 23:
			res = "c";
			break;

		case 24:
			res = "v";
			break;

		case 25:
			res = "b";
			break;
		case 26:
			res = "n";
			break;
		case 27:
			res = "m";
			break;
		case 28:
			res = "Back";
			break;

		case 29:
			res = ".?123";
			break;

		case 30:
			res = "Space";
			break;

		case 31:
			res = "Return";
			break;
		default:
			break;
		}
		return res;
	}

	/*
	 * This method is used to build up the keyPad letters
	 */
	public String getNumbers(int x) {
		String res = "";
		switch (x) {
		case 1:
			if (isSymbolsKeyPad)
				res = "[";
			else
				res = "1";
			break;

		case 2:
			if (isSymbolsKeyPad)
				res = "]";
			else
				res = "2";
			break;

		case 3:
			if (isSymbolsKeyPad)
				res = "{";
			else
				res = "3";
			break;

		case 4:
			if (isSymbolsKeyPad)
				res = "}";
			else
				res = "4";
			break;

		case 5:
			if (isSymbolsKeyPad)
				res = "#";
			else
				res = "5";
			break;

		case 6:
			if (isSymbolsKeyPad)
				res = "%";
			else
				res = "6";
			break;

		case 7:
			if (isSymbolsKeyPad)
				res = "^";
			else
				res = "7";
			break;

		case 8:
			if (isSymbolsKeyPad)
				res = "*";
			else
				res = "8";
			break;

		case 9:
			if (isSymbolsKeyPad)
				res = "+";
			else
				res = "9";
			break;

		case 10:
			if (isSymbolsKeyPad)
				res = "[";
			else
				res = "0";
			break;

		case 11:
			if (isSymbolsKeyPad)
				res = "_";
			else
				res = "-";
			break;

		case 12:
			if (isSymbolsKeyPad)
				res = "\\";
			else
				res = "/";
			break;

		case 13:
			if (isSymbolsKeyPad)
				res = "|";
			else
				res = ":";
			break;

		case 14:
			if (isSymbolsKeyPad)
				res = "~";
			else
				res = ";";
			break;

		case 15:
			if (isSymbolsKeyPad)
				res = "<";
			else
				res = "(";
			break;

		case 16:
			if (isSymbolsKeyPad)
				res = ">";
			else
				res = ")";
			break;

		case 17:
			res = "$";
			break;

		case 18:
			res = "&";
			break;

		case 19:
			res = "@";
			break;

		case 20:
			res = "\"";
			break;

		case 21:
			if (isSymbolsKeyPad)
				res = "123";
			else
				res = "#+=";
			break;

		case 22:
			res = ".";
			break;
		case 23:
			res = ",";
			break;

		case 24:
			res = "?";
			break;

		case 25:
			res = "!";
			break;
		case 26:
			res = "'";
			break;
		case 27:
			res = "Back";
			break;
		case 28:
			res = "abc";
			break;
		case 29:
			res = "Space";
			break;
		case 30:
			res = "Return";
			break;
		default:
			break;
		}
		return res;
	}

	/*
	 * Load image from "IMAGE_PATH"
	 * 
	 * Parameters: file - file name of the image
	 */
	private Image loadImage(String file) {
		URL url = getClass().getResource(IMAGE_PATH + file);
		Image image = null;

		try {
			image = java.awt.Toolkit.getDefaultToolkit().getImage(url);
			MediaTracker track = new MediaTracker(this);
			track.addImage(image, 0);

			try {
				track.waitForAll();
			} catch (InterruptedException e) {
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to load image: " + file);
		}

		return image;
	}

	/*
	 * public void hide() { setVisible(false);
	 * 
	 * 
	 * }
	 */

	/*
	 * This method is used to build up the keyPad letters
	 */
	public String getLetter(int x) {
		String res = "";
		switch (x) {
		case 1:
			res = "A";
			break;

		case 2:
			res = "B";
			break;

		case 3:
			res = "C";
			break;

		case 4:
			res = "D";
			break;

		case 5:
			res = "E";
			break;

		case 6:
			res = "F";
			break;

		case 7:
			res = "G";
			break;

		case 8:
			res = "H";
			break;

		case 9:
			res = "I";
			break;

		case 10:
			res = "J";
			break;

		case 11:
			res = "K";
			break;

		case 12:
			res = "L";
			break;

		case 13:
			res = "M";
			break;

		case 14:
			res = "N";
			break;

		case 15:
			res = "O";
			break;

		case 16:
			res = "P";
			break;

		case 17:
			res = "Q";
			break;

		case 18:
			res = "R";
			break;

		case 19:
			res = "S";
			break;

		case 20:
			res = "T";
			break;

		case 21:
			res = "U";
			break;

		case 22:
			res = "V";
			break;

		case 23:
			res = "W";
			break;

		case 24:
			res = "X";
			break;

		case 25:
			res = "Y";
			break;

		case 26:
			res = "Z";
			break;

		case 27:
			res = ",";
			break;

		case 28:
			res = "SPC";
			break;

		case 29:
			res = "<-";
			break;

		default:
			break;
		}
		return res;
	}

	/*
	 * This method is used to blink the cursor position in the text field
	 */
	public void blinkCursor(Graphics graph, boolean blink) {
		graph.setColor(Color.black);
		if (isTeamSelected) {
			if (blink) {
				graph.setColor(Color.black);
				graph.drawString(teamName, BANNER_INFO_LOC.x + 135,
						BANNER_INFO_LOC.y - 70);
				if (cursorindex != 0)
					graph.drawString(teamName.substring(0, cursorindex) + "|",
							BANNER_INFO_LOC.x + 135, BANNER_INFO_LOC.y - 70);
				else {
					String samp = "";
					for (int i = 0; i < samp.length(); i++) {
						samp = samp + " ";
					}
					graph.setColor(Color.black);
					graph.drawString(samp + "|", BANNER_INFO_LOC.x + 135,
							BANNER_INFO_LOC.y - 70);
				}
			} else {
				graph.setColor(Color.black);
				graph.drawString(teamName, BANNER_INFO_LOC.x + 135,
						BANNER_INFO_LOC.y - 70);
			}
		} else {
			if (blink) {
				graph.setColor(Color.black);
				graph.drawString(playerName, BANNER_INFO_LOC.x - 18,
						BANNER_INFO_LOC.y - 70);
				if (cursorindex != 0)
					graph.drawString(
							playerName.substring(0, cursorindex) + "|",
							BANNER_INFO_LOC.x - 18, BANNER_INFO_LOC.y - 70);
				else {
					String samp = "";
					for (int i = 0; i < samp.length(); i++) {
						samp = samp + " ";
					}
					graph.setColor(Color.black);
					graph.drawString(samp + "|", BANNER_INFO_LOC.x - 18,
							BANNER_INFO_LOC.y - 70);
				}
			} else {
				graph.setColor(Color.black);
				graph.drawString(playerName, BANNER_INFO_LOC.x - 18,
						BANNER_INFO_LOC.y - 70);
			}
		}
	}

	/*
	 * This Thread is used to make the cursor blink
	 */

	/*
	 * public class Blinking extends Thread { SearchPlayerScreen ban;
	 * 
	 * Blinking(SearchPlayerScreen ban) { this.ban = ban; }
	 * 
	 * public void run() { while (true) { try { if (ban.blinkcursor) {
	 * ban.blinkcursor = false; ban.repaint(); } else { ban.blinkcursor = true;
	 * ban.repaint(); } sleep(200L); } catch (InterruptedException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * 
	 * }
	 * 
	 * }
	 * 
	 * }
	 */

}
