package com.cts.csap.service;

import java.util.List;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;

import com.cts.csap.vo.CSAPUser;
import com.cts.csap.vo.Customer;
import com.cts.csap.vo.VendorOfferings;

@WebService
@SOAPBinding(parameterStyle=ParameterStyle.BARE)
public interface ICustomerService {

	Customer addCustomer(Customer customer);
	Customer validateCustomer(CSAPUser csapUser);
	VendorOfferings registerCustomerInterest(Customer customer, String productName,String productBrand,String productCategory);
	List<VendorOfferings> getRecommandations(Customer customer);
}
