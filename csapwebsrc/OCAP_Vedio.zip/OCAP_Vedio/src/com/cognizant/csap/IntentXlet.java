package com.cognizant.csap;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;
import java.util.List;

import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;

import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.dvb.ui.DVBTextLayoutManager;
import org.havi.ui.HContainer;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HSceneTemplate;
import org.havi.ui.HState;
import org.havi.ui.HText;
import org.havi.ui.HVisible;
import org.havi.ui.event.HRcEvent;

public class IntentXlet extends HContainer implements javax.tv.xlet.Xlet {

	private static final long serialVersionUID = 1L;
	
	private HScene hscene;
	private HText initialText = null;
		
	private int currentx;
	private int currenty;
	
	private boolean isStarted = false;
	private List textList = new ArrayList();

	
	public void destroyXlet(boolean arg0) throws XletStateChangeException {
		try {
			if (isStarted) {
				disposeApplication();
				isStarted = false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	public void initXlet(XletContext arg0) throws XletStateChangeException {
		try {
			currentx = 100;
			currenty = 450;
			initGUI();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	public void pauseXlet() {
		if (isStarted)
			hideApplication();
		
	}

	public void startXlet() throws XletStateChangeException {
		try {
			if (!isStarted) {
				isStarted = true;
			}
			showApplication();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	
	
	private void initGUI() {
		this.setLayout(null);
		this.setSize(640, 480);
		
		HSceneTemplate hst = new HSceneTemplate();
		hst.setPreference(HSceneTemplate.SCENE_SCREEN_DIMENSION, new org.havi.ui.HScreenDimension(1, 1), HSceneTemplate.REQUIRED);
		hst.setPreference(HSceneTemplate.SCENE_SCREEN_LOCATION,	new org.havi.ui.HScreenPoint(0, 0), HSceneTemplate.REQUIRED);

		this.hscene = HSceneFactory.getInstance().getBestScene(hst);

		//this.hscene = HSceneFactory.getInstance().getDefaultHScene();
		//this.hscene.setSize(640, 480);
		
		this.hscene.add(this);
		
		//show initial HText
		Font font1 = new Font("Arial", java.awt.Font.PLAIN, 14);
		DVBTextLayoutManager mgr1 = new org.dvb.ui.DVBTextLayoutManager();
		mgr1.setLineSpace(16);
		mgr1.setHorizontalAlign(
		  org.dvb.ui.DVBTextLayoutManager.HORIZONTAL_CENTER);
		mgr1.setVerticalAlign(
		  org.dvb.ui.DVBTextLayoutManager.VERTICAL_CENTER);

//		StringBuffer messageBuf = new StringBuffer("");
//		messageBuf.append("Offers - ");
//		messageBuf.append(getProductOffer());
//		messageBuf.append(" !! Press 3rd colour button on your remote to register interest, or 2nd colour button to cancel.");
//		initialText = new HText(messageBuf.toString(), 40, 400, 560, 80);
		initialText = new HText(
				"Offers - "+getProductOffer()+"!!  Press 3rd colour button on your remote to register interest, or 2nd colour button to cancel.", 
				40, 400, 560, 80
				);
		initialText.setForeground(Color.YELLOW);
		initialText.setBackground(Color.BLUE);
		initialText.setBackgroundMode(HVisible.BACKGROUND_FILL);
		initialText.setFont(font1);
		initialText.setTextLayoutManager(mgr1);
		initialText.setVisible(true);
		initialText.setFocusable(true);
		initialText.requestFocus();
		this.hscene.add(initialText);
		this.hscene.validate();
		
		
		
		UserEventRepository ueRepository = new UserEventRepository(" ");
		ueRepository.addAllColourKeys();
		ueRepository.addAllArrowKeys();
		ueRepository.addKey(HRcEvent.VK_ENTER);
		
		EventManager.getInstance().addUserEventListener(
				new UserEventListener() {
					public void userEventReceived(UserEvent userEvent) {
						System.out.println("key pressed = " + userEvent.getCode());
						if (userEvent.getCode() == HRcEvent.VK_COLORED_KEY_2) {
							try {
								System.out.println("Third color key pressed");
								.main(product, brand, );
								//message = "Thank You for showing your interest.";
								
								//remove the original text and display another one.
								initialText.setTextContent("Thanks for your interest in this item.  We will update you with our offers on your mobile device/online account/email.  Press the 2nd color button to dismiss this message.", HState.ALL_STATES);
								
							} catch (Exception e) {
								e.printStackTrace();
								initialText.setTextContent("Service is down. Please try later.", HState.ALL_STATES);
								//message = "Service is Down ..Please try later.";
							}
							repaint();
						}
						if (userEvent.getCode() == HRcEvent.VK_COLORED_KEY_1) {
							try {
								System.out.println("Second color key pressed. Terminating");
								initialText.setTextContent("Cancelling.. ", HState.ALL_STATES);
								Thread.sleep(2000);
								hideApplication(); //or should it be disposeApplication ??
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						if (userEvent.getCode() == HRcEvent.VK_COLORED_KEY_3) {
							System.out.println("fourth color key pressed");
							//show the table
							hscene.setVisible(true);
							initGUITable();
							initialText.transferFocus();
						}
					}
				}, ueRepository);
		
	}

	public void paint(Graphics g) {
		g.setColor(java.awt.Color.YELLOW);
		//g.drawString(message, currentx, currenty);
		//g.drawImage(img, x, y, observer);
		super.paint(g);
	}
	
	private void initGUITable() {
		//hscene.removeAll();
		this.currentx = 40;
		this.currenty = 40;
		
		int numRows = 4;
		int numCols = 2;
		
		GridLayout layout = new GridLayout(numRows, numCols);
		HContainer container = new HContainer();
		container.setLayout(layout);
		container.setBounds(currentx, currenty, 560, 240);
		
		for (int i = 0; i < numRows*numCols; i++) {
			HText textcomp = getHText("text-"+i);
			textList.add(textcomp);
			container.add(textcomp);
		}
		
		initialText.setFocusTraversal((HText)textList.get(0), (HText)textList.get(0), (HText)textList.get(0), (HText)textList.get(0));
		
		for (int i = 0; i < numRows*numCols; i += numCols) {

			HText textcomp = (HText)textList.get(i);
			if (i == 0) {
				textcomp.setFocusTraversal(null, (HText)textList.get(i+numCols), null, null);
			}
			else if (i == (numRows-1) * numCols) {
				textcomp.setFocusTraversal((HText)textList.get(i-numCols), null, null, null);
			}
			else {
				textcomp.setFocusTraversal((HText)textList.get(i-numCols), (HText)textList.get(i+numCols), null, null);
			}
		}
		
		//((HText)textList.get(3)).setFocusTraversal(((HText)textList.get(0)), ((HText)textList.get(6)), null, null);
		//((HText)textList.get(3)).transferFocus();
		
		container.setVisible(true);
		hscene.add(container);
		hscene.validate();
		hscene.repaint();
	}
	
	private HText getHText(String content) {
		Font font1 = new Font("Arial", java.awt.Font.PLAIN, 14);
		DVBTextLayoutManager mgr1 = new org.dvb.ui.DVBTextLayoutManager();
		mgr1.setLineSpace(18);
		mgr1.setHorizontalAlign(
		  org.dvb.ui.DVBTextLayoutManager.HORIZONTAL_CENTER);
		mgr1.setVerticalAlign(
		  org.dvb.ui.DVBTextLayoutManager.VERTICAL_CENTER);

		final HText text = new HText(content, 10, 10, content.length()*4, 30);
		text.setForeground(Color.YELLOW);
		text.setBackground(Color.BLUE); 
		text.setBackgroundMode(HVisible.BACKGROUND_FILL);
		text.setFocusable(true);
		text.addFocusListener( new FocusListener() {
			
			public void focusLost(FocusEvent e) {
				System.out.println("focus lost on " + text.getTextContent(HState.ALL_STATES));
				text.setForeground(Color.YELLOW);
			}
			
			public void focusGained(FocusEvent e) {
				System.out.println("focus gained on " + text.getTextContent(HState.ALL_STATES));
				text.setForeground(Color.RED);
			}	
		});
		
		// :) four PARMAS are UP, DOWN, LEFT, RIGHT :)
		//stoory is in my code, HTEXTDEMO2... please open it
		
		text.setVisible(true);
		text.validate();
		return text;
		
	}
	
	private void showApplication() {
		this.hscene.show();
		this.hscene.repaint();
	}

	private void hideApplication() {
		System.out.println("hiding the scene");
		this.hscene.setVisible(false);
	}

	private void disposeApplication() {
		hideApplication();
		//HScene tmp = hscene;
		//hscene = null;
		HSceneFactory.getInstance().dispose(hscene);
	}
	
	/** 
	 * Create a product hard coded for now.  Later , we may call a web service 
	 * to get some product details from there.
	 * @return
	 */
	private String getProductOffer() {
		CSAPServiceDelegate delegate = new CSAPServiceDelegate();
		String ad = delegate.getAd();
		return ad;
//		return "sample string related to product offer";
	}
	
	private void registerInterest() {
	}
	

}
