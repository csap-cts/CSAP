package org.ocapproject.xlet;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;
import org.havi.ui.event.HRcEvent;

import com.cognizant.iptv.digitalsubscriberservice.client.subscriber.DigitalSubscriberServiceClient;


//import com.cognizant.iptv.digitalsubscriberservice.client.subscriber.DigitalSubscriberServiceClient;

public class UserInterestXlet extends Container implements javax.tv.xlet.Xlet, Runnable{

	private static final long serialVersionUID = 1;
	private boolean m_started = false;
	private HScene m_scene;
	private static String message ="Buy Now !!!!!! DELL -DX100 Series Laptop.......INTERESTED ?";
	private static int FONT_SIZE = 26;
	private UserEventListener userEventListener;
	private Color backgroundColor;

	Thread userInterestXlet;

	int text_width;
	int current_x;
	int current_y;
	int start_x;
	int text_size;
	Color text_color;
	int applet_height;
	int applet_width;
	Image off_screen;
	Graphics off_screen_gc;


	public void initXlet(javax.tv.xlet.XletContext ctx)throws javax.tv.xlet.XletStateChangeException {
		try {
			current_x = 640;
			current_y = 450;
			start_x = 640;
			initGUI();
			if(userInterestXlet == null) {
				userInterestXlet = new Thread(this);
				userInterestXlet.start();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	public void startXlet() throws javax.tv.xlet.XletStateChangeException {
		try {
			if (!m_started) {
				m_started = true;
			}
			showApplication();
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	public void pauseXlet() {
		if (m_started)
			hideApplication();
	}

	public void destroyXlet(boolean forced)throws javax.tv.xlet.XletStateChangeException {
		try {
			if (m_started) {
				disposeApplication();
				m_started = false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
		}
	}

	void showApplication() {
		m_scene.show();
		m_scene.repaint();
	}

	void hideApplication() {
		m_scene.setVisible(false);
	}

	void disposeApplication() {
		hideApplication();

		HScene tmp = m_scene;
		m_scene = null;
		HSceneFactory.getInstance().dispose(tmp);
	}

	private void initGUI() {
        //System.out.println("initGUI:Aruna");
		setLayout(null);
		setSize(640, 480);
		m_scene = HSceneFactory.getInstance().getDefaultHScene();
		m_scene.setSize(640, 480);
		m_scene.add(this);
		setForeground(Color.blue);
		setBackground(Color.WHITE);
		setFont(new Font("SansSerif", Font.PLAIN, FONT_SIZE));
		
		//add a frame with three buttons here. 
		
		UserEventRepository userEventRepository = new UserEventRepository(" ");
		userEventRepository.addAllColourKeys();
		userEventListener = new UserEventListener() {
			public void userEventReceived(UserEvent userEvent) {
				//System.out.println("inSide EventListner:Aruna");
				userInterestXlet.interrupt();
				//if (userEvent.getType() == HRcEvent.KEY_PRESSED) {
					if (userEvent.getCode() == HRcEvent.VK_COLORED_KEY_2) {
						try {
							
							// DigitalSubscriberServiceClient.main(null);
							message = "Thank You for showing your interest.";
						} catch (Exception e) {
							e.printStackTrace();
							message = "Service is Down ..Please try later.";
						}
						
						backgroundColor = Color.BLACK;
						setFont(new Font("SansSerif", Font.PLAIN, 20));
						FONT_SIZE = 20;
						current_x=200;
						current_y=470;
					 }
					isAlive=false;
					repaint();
				//}
			}			
		};
		
		EventManager.getInstance().addUserEventListener(userEventListener,userEventRepository);
		m_scene.validate();
	}

	
	public void paint(Graphics g) {
		g.setColor(backgroundColor);
		g.drawString(message, current_x, current_y);
		super.paint(g);
	}
	
	boolean isAlive=true;
	
	public void run() {
		//Thread thread = Thread.currentThread();
		userInterestXlet.setPriority(1);
		text_width = message.length();

		while(isAlive)  {
			moveText_();
			try {
				Thread.sleep(2L);
			}
			catch(InterruptedException interruptedexception) { 
				//userInterestXlet.destroy();
			  }
		}
	}

	public void moveText_() {
		current_x--;
		if((current_x + text_width*5 )<= 0) 
			current_x = start_x;
		repaint();
	}

}


