package org.ocapproject.xlet;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.dvb.ui.DVBAlphaComposite;
import org.dvb.ui.DVBGraphics;
import org.dvb.ui.UnsupportedDrawingOperationException;

import sportsstats.com.cts.beans.HScore;
import sportsstats.com.cts.beans.PlayerData;
import sportsstats.com.cts.beans.PlayerStatsInfo;
import sportsstats.com.cts.model.Storage;
import sportsstats.com.cts.xlet.StatsXlet;

/**
 * 
 * @author bhanuprasad.gamidi@cognizant.com
 * 
 *         PlayerStatScreen render the PlayerStats of the Player. User will be
 *         selecting the player to get the playerStats Here the User can have
 *         Three option 1.He can search for another player. 2.He can go back to
 *         the Home(UserMenu) Screen. 3. He can exit the Application(Hiding the
 *         application).
 */

public class PlayerStatScreen extends Component {

	private static final long serialVersionUID = 1L;

	// Background image
	public Image m_background;

	public Image[] Stats = new Image[2];

	public String[] UserOptions;

	public Image[] homeButtons = new Image[2];

	public Image[] playButtons = new Image[2];

	public Image[] gameButtons = new Image[2];

	// Banner background picture and its location whent displaying stats
	private static final String BANNER_PIC_STATS = "/sportsstats/com/cts/xlet/SportsStatsImages/3rd_screen_bg.png";

	private static final Point BANNER_LOC_STATS = new Point(0, 0);
	// private static final Point BANNER_LOC_STATS = new Point(0, 0);

	private static final Point BANNER_INFO_LOC = new Point(30, 215);

	private static final Font BANNER_INFO_FONT = new Font("tiresias",
			Font.PLAIN, 16);

	private static final Color BANNER_INFO_COLOR = new Color(200, 200, 200); // text

	private static final String HILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/player_stats_btn_over.png";

	private static final String UNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/player_stats_btn.png";

	private static final String HOMEHILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn_over.png";

	private static final String HOMEUNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn.png";

	private static final String GAMEHILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn_over.png";

	private static final String GAMEUNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/home_btn.png";

	public ArrayList predictiveText;

	public int preTextindex;

	public int selectOption = 0;

	public boolean UserSelected;

	private int imagenumber = 0;

	public Image playerPhoto;

	public Image teamLogo;

	private MediaTracker mt = new MediaTracker(this);

	public PlayerStatsInfo playerstats = null;

	public boolean playerStat;

	public PlayerStatScreen() {
		// Load background image for PlayerStatsScreen
		if (Storage.screens.containsKey("PlayerStats")) {
			m_background = (Image) Storage.screens.get("PlayerStats");
			mt.addImage(m_background, this.imagenumber);
			++this.imagenumber;
		} else {
			m_background = loadImages(BANNER_PIC_STATS, true);
			Storage.screens.put("PlayerStats", m_background);
		}

		if (Storage.reqImages.containsKey("PlayerButtons")) {
			playButtons = (Image[]) Storage.reqImages.get("PlayerButtons");
			for (int i = 0; i < playButtons.length; i++) {
				mt.addImage(playButtons[i], i + this.imagenumber);
				++this.imagenumber;
			}
		} else {
			for (int i = 0; i < playButtons.length; i++) {
				if (i == 0)
					playButtons[i] = loadImages(HILIGHTED, true);
				else
					playButtons[i] = loadImages(UNHIGHLITED, true);
			}
			Storage.reqImages.put("PlayerButtons", playButtons);
		}
		URL url;
		if (Storage.reqImages.containsKey("HomeButtons")) {
			homeButtons = (Image[]) Storage.reqImages.get("HomeButtons");
			for (int i = 0; i < homeButtons.length; i++) {
				mt.addImage(homeButtons[i], i + this.imagenumber);
				++this.imagenumber;
			}
		} else {
			for (int i = 0; i < homeButtons.length; i++) {
				if (i == 0)
					url = this.getClass().getResource(HOMEHILIGHTED);
				else
					url = this.getClass().getResource(HOMEUNHIGHLITED);
				homeButtons[i] = java.awt.Toolkit.getDefaultToolkit().getImage(
						url);
			}
			Storage.reqImages.put("HomeButtons", homeButtons);
		}

		if (Storage.reqImages.containsKey("GameButtons")) {
			gameButtons = (Image[]) Storage.reqImages.get("GameButtons");
			for (int i = 0; i < gameButtons.length; i++) {
				mt.addImage(gameButtons[i], i + 3);
			}
		} else {
			for (int i = 0; i < gameButtons.length; i++) {
				if (i == 0)
					url = this.getClass().getResource(GAMEHILIGHTED);
				else
					url = this.getClass().getResource(GAMEUNHIGHLITED);
				gameButtons[i] = java.awt.Toolkit.getDefaultToolkit().getImage(
						url);
				mt.addImage(gameButtons[i], i + 3);

			}
			Storage.reqImages.put("GameButtons", gameButtons);
		}
		StatsXlet.m_scene.setBounds(116, 21, 308, 450);
		this.setBounds(0, 0, 308, 450);
		setFont(BANNER_INFO_FONT);
		setForeground(BANNER_INFO_COLOR);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paint(Graphics g) {
		DVBAlphaComposite c = DVBAlphaComposite.getInstance(
				DVBAlphaComposite.SRC_OVER, 0.9f);
		try {
			((DVBGraphics) g).setDVBComposite(c);
		} catch (UnsupportedDrawingOperationException e) {
			e.printStackTrace();
		}
		g.clearRect(0, 0, 640, 480);

		// Draw the background image
		g.drawImage(m_background, BANNER_LOC_STATS.x, BANNER_LOC_STATS.y, this);
		g.setFont(new Font("tiresias", Font.BOLD, 20));
		g.setColor(Color.white);
		g.drawString("Player Stats", BANNER_INFO_LOC.x + 50, 25);
		g.setFont(BANNER_INFO_FONT);
		PlayerData pl = playerstats.getPd();
		g.drawString("Name : " + pl.getFirstName() + "," + pl.getLastName(),
				BANNER_INFO_LOC.x + 85, BANNER_INFO_LOC.y - 75);
		g.drawString("Position : " + pl.getPosition(), BANNER_INFO_LOC.x + 85,
				BANNER_INFO_LOC.y - 55);

		if (Storage.serverReturnedValues.containsKey(pl.getFirstName()
				+ pl.getLastName() + "Image")) {
			playerPhoto = (Image) Storage.serverReturnedValues.get(pl
					.getFirstName()
					+ pl.getLastName() + "Image");
		} else {
			try {
				playerPhoto = java.awt.Toolkit.getDefaultToolkit().getImage(
						new URL("http://" + Storage.serverDet.get("serverIp")
								+ ":" + Storage.serverDet.get("serverPort")
								+ "/parser/PlayersPhotos/" + pl.getLastName()
								+ ".jpg"));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			Storage.serverReturnedValues.put(pl.getFirstName()
					+ pl.getLastName() + "Image", playerPhoto);
		}

		if (Storage.serverReturnedValues.containsKey(pl.getTeam() + "Image")) {
			teamLogo = (Image) Storage.serverReturnedValues.get(pl.getTeam()
					+ "Image");
		} else {
			try {
				teamLogo = java.awt.Toolkit.getDefaultToolkit().getImage(
						new URL("http://" + Storage.serverDet.get("serverIp")
								+ ":" + Storage.serverDet.get("serverPort")
								+ "/parser/" + pl.getTeam().trim() + ".png"));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			Storage.serverReturnedValues.put(pl.getTeam() + "Image", teamLogo);
		}

		if (playerPhoto != null) {
			System.out.println("height :" + playerPhoto.getHeight(null));
			System.out.println("height :" + playerPhoto.getWidth(null));
			g.drawImage(playerPhoto, BANNER_INFO_LOC.x - 15,
					BANNER_INFO_LOC.y - 170, BANNER_INFO_LOC.x + 80,
					BANNER_INFO_LOC.y - 60, 0, 0, playerPhoto.getWidth(this),
					playerPhoto.getHeight(this), this);
		} else {
			g.setColor(Color.red);
			g.drawString("Cannot load the image", BANNER_INFO_LOC.x - 14,
					BANNER_INFO_LOC.y + 130);
			g.setColor(Color.white);
		}

		if (teamLogo != null)
			g.drawImage(teamLogo, BANNER_INFO_LOC.x + 215,
					BANNER_INFO_LOC.y - 130, this);
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		// Displaying Season record
		creatingRoundTable(g, BANNER_INFO_LOC.x - 7, BANNER_INFO_LOC.y - 55,
				360, 70, 20, 20, "Season");

		// Displaying last10Games record
		creatingRoundTable(g, BANNER_INFO_LOC.x - 7, BANNER_INFO_LOC.y + 23,
				360, 70, 20, 20, "Last 10 Games");

		// Displaying vsCliffLee record
		creatingRoundTable(g, BANNER_INFO_LOC.x - 7,
				BANNER_INFO_LOC.y + 120 - 17, 360, 70, 20, 20, "vs CliffLee");
		if (selectOption == 0) {
			g.drawImage(playButtons[0], BANNER_INFO_LOC.x - 20,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(homeButtons[1], BANNER_INFO_LOC.x + 80,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(gameButtons[1], BANNER_INFO_LOC.x + 180,
					BANNER_INFO_LOC.y + 185, this);
		} else if (selectOption == 1) {
			g.drawImage(playButtons[1], BANNER_INFO_LOC.x - 20,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(homeButtons[0], BANNER_INFO_LOC.x + 80,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(gameButtons[1], BANNER_INFO_LOC.x + 180,
					BANNER_INFO_LOC.y + 185, this);
		} else {
			g.drawImage(playButtons[1], BANNER_INFO_LOC.x - 20,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(homeButtons[1], BANNER_INFO_LOC.x + 80,
					BANNER_INFO_LOC.y + 185, this);
			g.drawImage(gameButtons[0], BANNER_INFO_LOC.x + 180,
					BANNER_INFO_LOC.y + 185, this);
		}

		getToolkit().sync();
	}

	/**
	 * Shows the banner and starts the dismiss timer.
	 * 
	 * @param duration
	 */
	public void show(long duration) {
		setVisible(true);

	}

	/**
	 * loads the image from the specified path
	 * 
	 * @param imagePath
	 * @param local
	 * @return image
	 */
	private Image loadImages(String imagePath, boolean local) {
		// Load banner background image
		URL url = null;
		if (local)
			url = this.getClass().getResource(imagePath);
		else {
			try {
				url = new URL(imagePath);
			} catch (MalformedURLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		Image img = java.awt.Toolkit.getDefaultToolkit().getImage(url);
		// System.out.println(img.getHeight(this));
		// System.out.println(img.getWidth(this));
		mt.addImage(img, this.imagenumber);
		++this.imagenumber;
		try {
			mt.waitForAll();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return img;
	}

	// Building and Displaying the Record
	public void creatingRoundTable(Graphics g, int x, int y, int width,
			int height, int roundHor, int roundVer, String title) {
		System.out.println("Team name:" + playerstats.getPd().getTeam());
		for (int i = 0; i < 3; i++) {
			int k = 0;
			for (int j = 0; j < 11; j++) {
				if (i == 0) {
					g.setColor(Color.black);
					if (title.equalsIgnoreCase("vs CliffLee")) {
						String vsTeam = null;
						if (playerstats.getPd().getTeam().equalsIgnoreCase(
								"BRS")) {
							vsTeam = "vs CWS";
						} else {
							vsTeam = "vs BRS";
						}
						g.drawString(vsTeam, x - 7, y + 20);
					} else
						g.drawString(title, x - 7, y + 20);
					break;
				} else if (i == 1) {

					g.setColor(Color.black);
					// g.drawString(getPlayerStatVar(null, j), x + (j * 35) +
					// 25,
					// y + 20 + (i * 20));
					if (j <= 2) {
						g.drawString(getPlayerStatVar(null, j), x + (j * 15), y
								+ 20 + (i * 20));
					} else if (j <= 7) {
						g.drawString(getPlayerStatVar(null, j), x + (j * 22)
								- 12, y + 20 + (i * 20));
					} else {
						g.drawString(getPlayerStatVar(null, j), x + (j * 32)
								- 77, y + 20 + (i * 20));
						k++;
					}

				} else {
					g.setColor(Color.black);
					if (title.equalsIgnoreCase("Season")) {
						if (j <= 2) {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getSeason(), j), x + (j * 15), y + 30
									+ (i * 18));
						} else if (j <= 7) {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getSeason(), j), x + (j * 20) - 3, y + 30
									+ (i * 18));
						} else {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getSeason(), j), x + (j * 31) - 75, y + 30
									+ (i * 18));
							k++;
						}
						/*
						 * if(j<=7)
						 * g.drawString(getPlayerStatVar(playerstats.getPr()
						 * .getSeason(), j), x + (j * 30) + 10, y + 30 + (i *
						 * 20)); else
						 * g.drawString(getPlayerStatVar(playerstats.getPr()
						 * .getSeason(), j), x + (j * 31) + 35, y + 30 + (i *
						 * 20));
						 */
					} else if (title.equalsIgnoreCase("Last 10 Games")) {
						if (j <= 2) {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getLastTen(), j), x + (j * 15), y + 30
									+ (i * 18));
						} else if (j <= 7) {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getLastTen(), j), x + (j * 20) - 3, y + 30
									+ (i * 18));
						} else {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getLastTen(), j), x + (j * 31) - 75, y
									+ 30 + (i * 18));
							k++;
						}
						/*
						 * if(j<=7)
						 * g.drawString(getPlayerStatVar(playerstats.getPr()
						 * .getLastTen(), j), x + (j * 30) + 10, y + 30 + (i *
						 * 20)); else
						 * g.drawString(getPlayerStatVar(playerstats.getPr()
						 * .getLastTen(), j), x + (j * 31) + 35, y + 30 + (i *
						 * 20));
						 */

					} else if (title.equalsIgnoreCase("vs CliffLee")) {
						if (j <= 2) {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getVsTeam(), j), x + (j * 15), y + 30
									+ (i * 18));
						} else if (j <= 7) {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getVsTeam(), j), x + (j * 20) - 3, y + 30
									+ (i * 18));
						} else {
							g.drawString(getPlayerStatVar(playerstats.getPr()
									.getVsTeam(), j), x + (j * 31) - 75, y + 30
									+ (i * 18));
							k++;
						}

						/*
						 * if(j<=7)
						 * g.drawString(getPlayerStatVar(playerstats.getPr()
						 * .getVsTeam(), j), x + (j * 30) + 10, y + 30 + (i *
						 * 20)); else
						 * g.drawString(getPlayerStatVar(playerstats.getPr()
						 * .getVsTeam(), j), x + (j * 31) + 35, y + 30 + (i *
						 * 20));
						 */
					}

				}
			}
			g.setColor(Color.white);

		}

	}

	/*
	 * getPlayerStatVar returns the Stringobject of the Field for a given HScore
	 */
	public String getPlayerStatVar(HScore t, int i) {
		String res = null;
		String res1 = null;
		try {
			if (t != null) {
				switch (i) {
				case 0:
					res = Integer.toString(t.getR());
					break;
				case 1:
					res = Integer.toString(t.getH());
					break;
				case 2:
					res = Integer.toString(t.getHR());
					break;
				case 3:
					res = Integer.toString(t.getRBI());
					break;
				case 4:
					res = Integer.toString(t.getBB());
					break;
				case 5:
					res = Integer.toString(t.getSO());
					break;
				case 6:
					res = Integer.toString(t.getSB());
					break;
				case 7:
					res1 = Float.toString(t.getAVG());
					if (t.getAVG() == 0) {
						res = "0";
					} else {
						// if (res1.charAt(0) == '0') {
						res = res1.substring(1, res1.length());
						// }
					}
					break;
				case 8:

					res1 = Float.toString(t.getOBP());
					if (t.getOBP() == 0) {
						res = "0";
					} else {
						// if (res1.charAt(0) == '0') {
						res = res1.substring(1, res1.length());
						// }
					}
					break;
				case 9:

					res1 = Float.toString(t.getOPS());
					if (t.getOPS() == 0) {
						res = "0";
					} else {
						// if (res1.charAt(0) == '0') {
						res = res1.substring(1, res1.length());
						// }
					}
					break;
				case 10:

					res1 = Float.toString(t.getSLG());
					if (t.getSLG() == 0) {
						res = "0";
					} else {
						// if (res1.charAt(0) == '0') {
						res = res1.substring(1, res1.length());
						// }
					}
					break;

				default:
					break;
				}
			} else {
				switch (i) {
				case 0:
					res = "R";
					break;
				case 1:
					res = "H";
					break;
				case 2:
					res = "HR";
					break;
				case 3:
					res = "RBI";
					break;
				case 4:
					res = "BB";
					break;
				case 5:
					res = "SO";
					break;
				case 6:
					res = "SB";
					break;
				case 7:
					res = "AVG";
					break;
				case 8:
					res = "OBP";
					break;
				case 9:
					res = "OPS";
					break;
				case 10:
					res = "SLG";
					break;

				default:
					break;
				}
			}
		} catch (RuntimeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

}
