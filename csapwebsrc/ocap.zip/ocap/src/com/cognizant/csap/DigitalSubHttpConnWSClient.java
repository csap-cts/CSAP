package com.cognizant.csap;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import com.cognizant.csap.VendorOfferOcap;

public class DigitalSubHttpConnWSClient {

	
	String ns = "http://service.csap.cts.com/";
    
    String soapns = "http://schemas.xmlsoap.org/soap/envelope/";

	public String[] getAdv() {
		
		String operation = "getRandomProductForOCAP";
		String wsURLStr = "http://csapservices.cloudfoundry.com/CustomerService";
		
		String messageStr = 
			"<?xml version=\"1.0\" standalone=\"yes\"?>" +
			"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
		               "xmlns:ns1=\"" + ns + "\">" + 
		    "<soap:Body>" + 
//		    	"<ns1:" + operation + ">" + 
//		    	"</ns1:" + operation + ">" +
		    "</soap:Body>" +
		    "</soap:Envelope>";

		String[] offerStr = null;
		try {
			String outputString = getSOAPResponse(messageStr, wsURLStr);
	        Document xmlDoc = parseResponse(outputString);
	        offerStr = getOfferString(xmlDoc);
		} catch (IOException e) {
			System.out.println("getAdv");
			e.printStackTrace();
			//TODO : show error to user
		} catch (Exception e) {
			System.out.println("getAdv");
			e.printStackTrace();
		}
        return offerStr; 
	}
	
	
	
	public List registerInterest(String csapUserId, String productBrand, String productName) {

		String operation = "";
		String wsURLStr = "http://csapservices.cloudfoundry.com/CustomerService";
		
		String messageStr = 
		"<soapenv:Envelope " +
		"xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
		"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" " +
		"xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" " +
		"xmlns:ser=\"http://service.csap.cts.com/\">" +
		   "<soapenv:Header />"+
		   "<soapenv:Body>"+
			   //"<ser:registerCustomerInterestForOCAP>"+
//		      "<csapUserId xsi:type=\"xsd:string\">" + csapUserId + "</csapUserId>"+
//		      "<productName xsi:type=\"xsd:string\">" + productName + "</productName>"+
//		      "<productBrand xsi:type=\"xsd:string\">" + productBrand + "</productBrand>"+
		      "<csapUserId>" + csapUserId + "</csapUserId>"+
		      "<productBrand>" + productBrand + "</productBrand>"+
		      "<productName>" + productName + "</productName>"+
	    	   //"</ser:registerCustomerInterestForOCAP>"+
		   "</soapenv:Body>"+
		"</soapenv:Envelope>";

		List vendorOfferOcapList = new ArrayList();
		
		try {
			String outputString = getSOAPResponse(messageStr, wsURLStr);
			Document doc = parseResponse(outputString);
			vendorOfferOcapList = getVendorOffers(doc);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return vendorOfferOcapList;
	}
	
	private List getVendorOffers(Document doc) {
		List offerlist = new ArrayList();
		
		NodeList nodeList = doc.getElementsByTagName("vendorOffers");
		
		for (int i = 0; i < nodeList.getLength(); i++) {
			Element vendorOfferElement = (Element)nodeList.item(i);
			VendorOfferOcap vendorOffer = new VendorOfferOcap();
			
			Element vendorElement = getChildElementByName(vendorOfferElement, "vendor");
			Element vendorNameElement = getChildElementByName(vendorElement, "name");
			vendorOffer.setVendorName(getElementValue(vendorNameElement));
			
			Element offerTypeElement = getChildElementByName(vendorOfferElement, "offerType");
			vendorOffer.setOfferType(getElementValue(offerTypeElement));
			
			Element offerElement = getChildElementByName(vendorOfferElement, "offer");
			vendorOffer.setOffer(getElementValue(offerElement));
			
			Element worthPriceElement = getChildElementByName(vendorOfferElement, "worthPrice");
			String worthPriceStr = getElementValue(worthPriceElement);
			vendorOffer.setWorthPrice(Float.parseFloat(worthPriceStr));
			
			Element startDateElement = getChildElementByName(vendorOfferElement, "startDate");
			String startDateStr = getElementValue(startDateElement);
			vendorOffer.setStartDate(getDateFromString(startDateStr));
			
			Element endDateElement = getChildElementByName(vendorOfferElement, "endDate");
			String endDateStr = getElementValue(endDateElement);
			vendorOffer.setEndDate(getDateFromString(endDateStr));
			
			//System.out.println("vendor offer object = " + vendorOffer);	
			offerlist.add(vendorOffer);
		}
		
		
		return offerlist;
	}



	private String[] getOfferString(Document xmlDoc) {
		Element rootElement = xmlDoc.getDocumentElement();
		Element offerElement = (Element) rootElement.getFirstChild().getFirstChild();
		
		Element brandElement = getChildElementByName(offerElement, "brand");
		String brandValue = getElementValue(brandElement);
		
		Element categoryElement = getChildElementByName(offerElement, "category");
		String categoryValue = getElementValue(categoryElement);
		
		Element nameElement = getChildElementByName(offerElement, "name");
		String productNameValue = getElementValue(nameElement);
		
		String[] offerProductVals = new String[3];
		offerProductVals[0] = categoryValue;
		offerProductVals[1] = brandValue;
		offerProductVals[2] = productNameValue;
		
		return offerProductVals;
		
//		String productAdv = categoryValue + " " + brandValue + "::" + productNameValue;
//		System.out.println("product - " + productAdv);
//		return productAdv;

	}

	
	//Common methods
	
	private String getSOAPResponse(String messageStr, String wsURLStr) throws Exception {
		URL url = null;  
        URLConnection connection = null;  
        HttpURLConnection httpConn = null;  
        String responseString = null;
        String outputString = "";
        //ByteArrayOutputStream bout = null;  
        OutputStream out = null;  
        InputStreamReader isr = null;  
        BufferedReader in = null;  
        try   
        {  
    		String xmlInput = messageStr;
            url = new URL(wsURLStr);
            connection = url.openConnection();  
            httpConn = (HttpURLConnection) connection;
//            bout = new ByteArrayOutputStream();  
//            byte[] buffer = new byte[xmlInput.length()];  
//            buffer = xmlInput.getBytes();
            byte[] buffer = xmlInput.getBytes();
            //bout.write(buffer);
            //byte[] bArr = bout.toByteArray();  
            System.out.println("String request = " + new String(buffer));
            System.out.println();
            String SOAPAction = "";
            // Set the appropriate HTTP parameters.  
            httpConn.setRequestProperty("Content-Length", String  
                    .valueOf(buffer.length));  
            httpConn.setRequestProperty("Content-Type",  
                    "text/xml; charset=utf-8");  
            httpConn.setRequestProperty("SOAPAction", SOAPAction);  
            httpConn.setRequestMethod("POST");  
            httpConn.setDoOutput(true);  
            httpConn.setDoInput(true);  
            out = httpConn.getOutputStream();
            out.write(buffer);
            // Read the response and write it to standard out.  
            isr = new InputStreamReader(httpConn.getInputStream());  
            in = new BufferedReader(isr);  
            while ((responseString = in.readLine()) != null)   
            {  
                outputString = outputString + responseString;  
            }
            System.out.println(outputString);
        }
        catch (IOException e) {
        	e.printStackTrace();
        	throw new IOException("ERROR: communication with webservice failed", e);
		}
        catch (Exception e) {
        	e.printStackTrace();
        	throw e;
        }
        finally {
        	try {
        		out.close();
        		in.close();
        		httpConn.disconnect();
//        		bout.close();
        	}
        	catch(Exception e) {
        		e.printStackTrace();
        	}
        }
        return outputString;
	}

	private String getElementValue(Element elem) {
		NodeList list = elem.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node node = list.item(i);
			if (node.getNodeType() == Node.TEXT_NODE) {
				return node.getNodeValue();
			}
		}
		return null;
	}
	
	/**
	 * Get the child Element of the given element, with the given name. 
	 * Returns the first element found. 
	 * null if not found. 
	 * @param elem
	 * @return
	 */
	private Element getChildElementByName(Element elem, String name) {
		NodeList list = elem.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node childNode = list.item(i);
			if (childNode.getNodeType() == Node.ELEMENT_NODE) {
				//this is an element type.. check its name
				if (childNode.getNodeName().equals(name)) {
					// found element of given name directly under "elem" in the DOM tree. Return this
					return (Element)childNode;
				}
			}
		}
		return null;
	}
	
	private Document parseResponse(String xmlStr) {
		Document doc = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			//factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			
			doc = builder.parse(new InputSource(new StringReader(xmlStr)));
		}
		catch(ParserConfigurationException pce) {
			pce.printStackTrace();
		} 
		catch (SAXException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return doc;
	}
	
	public java.util.Date getDateFromString(String dateStr) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		java.util.Date date = null;
		try {
			date = sdf.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public static void main(String args[]) {
		String[] offerStr = new DigitalSubHttpConnWSClient().getAdv();
		System.out.println(" offer product - category, brand, name = " + Arrays.toString(offerStr));
		new DigitalSubHttpConnWSClient().registerInterest("cust1", offerStr[1], offerStr[2]);
		
		
//		String dateStr = "2012-07-24T13:36:01.619Z";
//		System.out.println("Date - " + new DigitalSubHttpConnWSClient().getDateFromString(dateStr));
		
		
	}
}
