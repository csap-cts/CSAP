package com.cts.csap.vo;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Customer extends CSAPUser {
	
	private static final Logger logger = LoggerFactory.getLogger(Customer.class);

	private String name;
	private String email;
	private String mobile;
	@DBRef
	private Address billingAddress;
	@DBRef
	private Address shippingAddress;
	@DBRef
	private List<SocialAccount> socialAccounts;

	public Customer() {
		
	}
	
	public Customer(String name, String email, String mobile,
			Address billingAddress, Address shippingAddress, String csapUserId,
			String csapPassword, List<SocialAccount> socialAccounts) {
		
		super(csapUserId, csapPassword, CSAPUserRoles.CUSTOMER);
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.billingAddress = billingAddress;
		this.shippingAddress = shippingAddress;
		this.socialAccounts = socialAccounts;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Address getBillingAddress() {
		return billingAddress;
	}
	public void setBillingAddress(Address billingAddress) {
		this.billingAddress = billingAddress;
	}
	public Address getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	
	public List<SocialAccount> getSocialAccounts() {
		return socialAccounts;
	}
	public void setSocialAccounts(List<SocialAccount> socialAccounts) {
		this.socialAccounts = socialAccounts;
	}

	@Override
	public String toString() {
		return "Customer [userName=" + getUserName() + ",password=" + getPassword() + ", name=" + name + ", email=" + email
				+ ", mobile=" + mobile + ", billingAddress=" + billingAddress
				+ ", shippingAddress=" + shippingAddress + ", socialAccounts="
				+ socialAccounts + "]";
	}

}
