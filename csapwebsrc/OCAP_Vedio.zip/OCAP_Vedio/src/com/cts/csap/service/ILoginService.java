package com.cts.csap.service;

import java.util.List;

import javax.jws.WebService;

import com.cts.csap.vo.CSAPUser;
import com.cts.csap.vo.Product;

@WebService
public interface ILoginService {

	CSAPUser validateUser(String userName, String password);
	List<Product> loadData();
	List<String> listCategory();
	String listBrands(String category);
	String listproducts(String brand, String category);
	List<Product> findAllProducts();

}