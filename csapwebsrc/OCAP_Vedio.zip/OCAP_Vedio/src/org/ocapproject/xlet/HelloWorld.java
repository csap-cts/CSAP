/*
 * Copyright (c) 2010, Cable Television Laboratories, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer. 
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution. 
 *   3. Neither the name of CableLabs, Inc. nor the names of its contributors
 *      may be used to endorse or promote products derived from this software
 *      without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

// Declare package.
package org.ocapproject.xlet;

// Import Personal Java packages.
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

import javax.tv.xlet.XletStateChangeException;

import org.havi.ui.HScene;
import org.havi.ui.HSceneFactory;

/**
 * The class presents a simple HelloWorld example for writing an
 * OCAP application. It makes use of the HAVi API.
 *
 * @author Cable Television Laboratories, Inc.
 */
public class HelloWorld extends Container implements javax.tv.xlet.Xlet
{
    private static final long serialVersionUID = 1;

    // A flag indicating that the Xlet has been started.
    private boolean m_started = false;

    // A HAVi Scene.
    private HScene m_scene;

    // Locations and bounding regions for all visual elements.
    private static final Point STR_LOCATION = new Point(100, 87);

    private static final String HELLOWORLD_STR = "Hello World!";

    private static final int FONT_SIZE = 16;

    /**
     * Initializes the OCAP Xlet.
     * <p>
     * A reference to the context is stored for further need.
     * This is the place where any initialisation should be done,
     * unless it takes a lot of time or resources.
     * </p>
     *
     * @param The context for this Xlet is passed in.
     *
     * @throws XletStateChangeException If something goes wrong, then an
     * XletStateChangeException is sent so that the runtime system knows that
     * the Xlet can't be initialised.
     */
    public void initXlet(javax.tv.xlet.XletContext ctx) throws javax.tv.xlet.XletStateChangeException
    {
        try
        {
            initGUI();
        } catch (Exception ex)
        {
            ex.printStackTrace();
            throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
        }
    }

    /**
     * Starts the OCAP Xlet.
     *
     * @throws XletStateChangeException If something goes wrong, then an
     * XletStateChangeException is sent so that the runtime system knows that
     * the Xlet can't be started.
     */
    public void startXlet() throws javax.tv.xlet.XletStateChangeException
    {
        try
        {
            if (!m_started)
            {
                m_started = true;
            }
            // Display the application.
            showApplication();
        } catch (Exception ex)
        {
            ex.printStackTrace();
            throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
        }
    }

    /**
     * Pauses the OCAP Xlet.
     */
    public void pauseXlet()
    {
        if (m_started)
        // Hide the application.
            hideApplication();
    }

    /**
     * Destroys the OCAP Xlet.
     *
     * @throws XletStateChangeException If something goes wrong, then an
     * XletStateChangeException is sent so that the runtime system knows that
     * the Xlet can't be destroyed.
     */
    public void destroyXlet(boolean forced) throws javax.tv.xlet.XletStateChangeException
    {
        try
        {
            if (m_started)
            {
                // Hide the application.
                disposeApplication();
                m_started = false;
            }
        } catch (Exception ex)
        {
            ex.printStackTrace();
            throw new javax.tv.xlet.XletStateChangeException(ex.getMessage());
        }
    }

    /**
     * Show the application.
     * <p>
     * The HAVi scene is repainted.
     * </p>
     */
    void showApplication()
    {
        m_scene.show();
        m_scene.repaint();
    }

    /**
     * Hide the application.
     * <p>
     * The HAVi scene is set invisible.
     * </p>
     */
    void hideApplication()
    {
        m_scene.setVisible(false);
    }

    /**
     * Dispose of the application resources.
     * <p>
     * The HAVi scene is disposed of.
     * </p>
     */
    void disposeApplication()
    {
        // Hide the application.
        hideApplication();

        // Clean up and dispose of resources.
        HScene tmp = m_scene;
        m_scene = null;
        HSceneFactory.getInstance().dispose(tmp);
    }

    /*
     * Initialize the application graphical user interface.
     */
    private void initGUI()
    {
        // Initialize the Container layout.
        setLayout(null);
        setSize(640, 480);

        // Create HScene and initialize it.
        m_scene = HSceneFactory.getInstance().getDefaultHScene();
        // Set the size of the scene, if not already set.
        m_scene.setSize(640, 480);
        // Add the container to the scene.
        m_scene.add(this);

        // Initialize the display characteristics.
        setForeground(Color.white);
        setBackground(Color.lightGray);
        setFont(new Font("SansSerif", Font.BOLD, FONT_SIZE));

        //Clean up stuff by calling garbage collection.
        System.gc();
        validate();
    }

    /**
     * Paint all.
     *
     * @param g The <code>Graphics</code> context.
     */
    public void paint(Graphics g)
    {
        // Draw the string.
        g.drawString(HELLOWORLD_STR, STR_LOCATION.x, STR_LOCATION.y);

        super.paint(g);
    }
}
