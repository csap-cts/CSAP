package com.cognizant.csap;



//a simple delegate to call WS. 
public class CSAPServiceDelegate {

	public String getAd() {
		DigitalSubHttpConnWSClient client = new DigitalSubHttpConnWSClient();
		return client.getAdv();
	}
}
