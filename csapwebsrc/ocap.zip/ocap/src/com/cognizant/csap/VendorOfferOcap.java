package com.cognizant.csap;

public class VendorOfferOcap {

	private String id;
	private String offer;
	private String offerType;
	private float worthPrice;
	private java.util.Date startDate;
	private java.util.Date endDate;
	private String vendorName;
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getOffer() {
		return offer;
	}
	public void setOffer(String offer) {
		this.offer = offer;
	}
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public float getWorthPrice() {
		return worthPrice;
	}
	public void setWorthPrice(float worthPrice) {
		this.worthPrice = worthPrice;
	}
	public java.util.Date getStartDate() {
		return startDate;
	}
	public void setStartDate(java.util.Date startDate) {
		this.startDate = startDate;
	}
	public java.util.Date getEndDate() {
		return endDate;
	}
	public void setEndDate(java.util.Date endDate) {
		this.endDate = endDate;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String toString() {
		return "VendorOfferOcap [id=" + id + ", offer=" + offer
				+ ", offerType=" + offerType + ", worthPrice=" + worthPrice
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", vendorName=" + vendorName + "]";
	}
	
}
