package com.cognizant.iptv.digitalsubscriberservice.client.subscriber;

import java.io.StringReader;
import java.net.URI;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.addressing.client.ActionCallback;
import org.springframework.xml.transform.StringResult;
import org.springframework.xml.transform.StringSource;

public class DigitalSubscriberServiceClient {

    private URI action;
    private String defaultUri;
    
    private final WebServiceTemplate webServiceTemplate = new WebServiceTemplate();
    
    public void recordSubscriberInterest(String advertizement_Id, String subscriber_Id) throws Exception {
        Source requestSource = new StringSource("<RecordSubscriberInterestRequest xmlns=\"http://www.cognizant.com/iptv/digitalsubsciber/DigitalSubscriberService\">" +
        		"<Record_SubscriberInterest_Info>" +
        		"<Advertizement_Id>" + advertizement_Id + "</Advertizement_Id>" +
        		"<Subscriber_Id>" + subscriber_Id + "</Subscriber_Id>" +
        		"</Record_SubscriberInterest_Info>" +
        		"</RecordSubscriberInterestRequest>");
       
        StringResult result = new StringResult();
        
        //this.getWebServiceTemplate().sendSourceAndReceiveToResult(requestSource, new ActionCallback(action), result);
        
        System.out.println(result);
    }

    public static void main(String[] args) throws Exception {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("../../../../../../applicationContext.xml", DigitalSubscriberServiceClient.class);
       
        DigitalSubscriberServiceClient digitalSubscriberServiceClient  = (DigitalSubscriberServiceClient) applicationContext.getBean("digitalSubscriberServiceClient");
        
        //digitalSubscriberServiceClient.recordSubscriberInterest("AD10000002323001", "STB23322323232323");
        digitalSubscriberServiceClient.getOfferForAd();
    }

    public String getOfferForAd() {
    	String message = "<findAllProducts " +
    			"xmlns=\"http://service.csap.cts.com/\">" +
        		"</findAllProducts>";

    	StreamSource requestSource = new StreamSource(new StringReader(message));
    	StreamResult result = new StreamResult(System.out);
    	webServiceTemplate.sendSourceAndReceiveToResult("http://csapservices.cloudfoundry.com/LoginService", 
    			requestSource, result);
    	return "Dell Latitude E6400";
    }

	public void setDefaultUri(String defaultUri) {
		this.defaultUri = defaultUri;
	}

	public String getDefaultUri() {
		return defaultUri;
	}

	public void setAction(URI action) {
		this.action = action;
	}

	public URI getAction() {
		return action;
	}
}
