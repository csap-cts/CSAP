package org.ocapproject.xlet;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.net.MalformedURLException;
import java.net.URL;

import org.dvb.ui.DVBAlphaComposite;
import org.dvb.ui.DVBGraphics;
import org.dvb.ui.UnsupportedDrawingOperationException;

import sportsstats.com.cts.beans.BoxScore;
import sportsstats.com.cts.beans.BoxScore.Team;
import sportsstats.com.cts.model.Storage;
import sportsstats.com.cts.xlet.StatsXlet;

/**
 * 
 * @author bhanuprasad.gamidi@cognizant.com
 * 
 *         UserMenuScreen Provides the User To browse his present options in the
 *         Application and upon uSer selction Navigates the User to the
 *         respective Screens
 */

public class UserMenuScreen extends Component {

	private static final long serialVersionUID = 1L;

	// Background image
	public Image m_background;

	public Image team1;

	public Image team2;

	public Image[] gameButtons = new Image[2];

	public Image[] playButtons = new Image[2];

	public BoxScore initialBoxScore = null;

	// Banner background picture and its location

	private static final String BANNER_PIC = "/sportsstats/com/cts/xlet/SportsStatsImages/1st_screen_bg.png";

	private static final String BANNER_PIC1 = "/sportsstats/com/cts/xlet/SportsStatsImages/2nd_screen_bg.png";

	private static final Point BANNER_LOC = new Point(0, 0);

	// Channel info on the banner
	private static final Point BANNER_INFO_LOC = new Point(30, 215);

	private static final Font BANNER_INFO_FONT = new Font("tiresias",
			Font.PLAIN, 14);

	private static final Font BANNER_ERROR_FONT = new Font("tiresias",
			Font.PLAIN, 20);

	private static final Color BANNER_INFO_COLOR = new Color(200, 200, 200); // text

	private static final String GAMEHILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/game_stats_logo_over.png";

	private static final String GAMEUNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/game_stats_logo.png";

	private static final String PLAYERHILIGHTED = "/sportsstats/com/cts/xlet/SportsStatsImages/player_stats_btn_over.png";

	private static final String PLAYERUNHIGHLITED = "/sportsstats/com/cts/xlet/SportsStatsImages/player_stats_btn.png";

	public int index = 0;

	public String ErrorMessage = "";

	public UserMenuScreen() {
		System.out.println("In userMenu constructor");

		URL url;

		// loading background image for UserMenu screen

		if (Storage.screens.containsKey("UserMenu")) {
			m_background = (Image) Storage.screens.get("UserMenu");
		} else {
			url = this.getClass().getResource(BANNER_PIC);
			m_background = java.awt.Toolkit.getDefaultToolkit().getImage(url);
			Storage.screens.put("UserMenu", m_background);
		}

		try {
			if (Storage.reqImages.containsKey("Team1Logo")) {
				team1 = (Image) Storage.reqImages.get("Team1Logo");

			} else {
				team1 = java.awt.Toolkit.getDefaultToolkit().getImage(
						new URL("http://" + Storage.serverDet.get("serverIp")
								+ ":" + Storage.serverDet.get("serverPort")
								+ "/parser/CWS.png"));
				Storage.reqImages.put("Team1Logo", team1);
			}
			if (Storage.reqImages.containsKey("Team2Logo")) {
				team2 = (Image) Storage.reqImages.get("Team2Logo");

			} else {
				team2 = java.awt.Toolkit.getDefaultToolkit().getImage(
						new URL("http://" + Storage.serverDet.get("serverIp")
								+ ":" + Storage.serverDet.get("serverPort")
								+ "/parser/BRS.png"));
				Storage.reqImages.put("Team2Logo", team2);
			}
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}

		MediaTracker mt = new MediaTracker(this);
		mt.addImage(m_background, 0);
		mt.addImage(team1, 1);
		mt.addImage(team2, 2);
		// loading Required button images for UserMenu Screen
		if (Storage.reqImages.containsKey("GameButtons")) {
			gameButtons = (Image[]) Storage.reqImages.get("GameButtons");
			for (int i = 0; i < gameButtons.length; i++) {
				mt.addImage(gameButtons[i], i + 3);
			}
		} else {
			for (int i = 0; i < gameButtons.length; i++) {
				if (i == 0)
					url = this.getClass().getResource(GAMEHILIGHTED);
				else
					url = this.getClass().getResource(GAMEUNHIGHLITED);
				gameButtons[i] = java.awt.Toolkit.getDefaultToolkit().getImage(
						url);
				mt.addImage(gameButtons[i], i + 3);

			}
			Storage.reqImages.put("GameButtons", gameButtons);
		}

		if (Storage.reqImages.containsKey("PlayerButtons")) {
			playButtons = (Image[]) Storage.reqImages.get("PlayerButtons");
			for (int i = 0; i < playButtons.length; i++) {
				mt.addImage(playButtons[i], i + 5);
			}
		} else {
			for (int i = 0; i < playButtons.length; i++) {
				if (i == 0)
					url = this.getClass().getResource(PLAYERHILIGHTED);
				else
					url = this.getClass().getResource(PLAYERUNHIGHLITED);
				playButtons[i] = java.awt.Toolkit.getDefaultToolkit().getImage(
						url);
				mt.addImage(playButtons[i], i + 5);

			}
			Storage.reqImages.put("PlayerButtons", playButtons);
		}

		initialBoxScore = (BoxScore) Storage.serverReturnedValues
				.get("InitialBoxScore");

		try {
			mt.waitForAll();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		StatsXlet.m_scene.setBounds(116, 21, 308, 500);
		// Set this component's location and size
		this.setBounds(0, 0, 308, 500);
		setFont(BANNER_INFO_FONT);
		setForeground(BANNER_INFO_COLOR);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.Component#paint(java.awt.Graphics)
	 */
	public void paint(Graphics g) {
		// System.out.println("In userMenu paint");
		DVBAlphaComposite c = DVBAlphaComposite.getInstance(
				DVBAlphaComposite.SRC_OVER, 0.9f);
		try {
			((DVBGraphics) g).setDVBComposite(c);
		} catch (UnsupportedDrawingOperationException e) {
			e.printStackTrace();
		}
		g.clearRect(0, 0, 308, 500);
		if (ErrorMessage.equals("")) {
			// Draw the banner background
			g.drawImage(m_background, BANNER_LOC.x, BANNER_LOC.y, this);
			g.setFont(new Font("tiresias", Font.BOLD, 20));
			g.setColor(Color.white);
			g.drawString("Welcome to Sports Stats", BANNER_INFO_LOC.x + 30, 25);
			int y = this.getFontMetrics(getFont()).getAscent();
			g.setColor(Color.white);
			g.setFont(new Font("Arial", Font.PLAIN, 15));
			g.drawString("Please select an option from below   ",
					BANNER_INFO_LOC.x + 8, BANNER_INFO_LOC.y + 125);
			g.drawString("using remote Arrow keys and the Select Key ",
					BANNER_INFO_LOC.x - 12, BANNER_INFO_LOC.y + 142);

			if (initialBoxScore != null) {
				// Display HIghlevel score
				String teamname1 = initialBoxScore.getTeams()[0].getName();
				String teamname2 = "";
				if (teamname1.equalsIgnoreCase("CWS")) {
					teamname1 = "Chicago White shoes";
					teamname2 = "Boston Red shoes";

				} else {
					teamname1 = "Boston Red shoes";
					teamname2 = "Chicago White shoes";
				}
				// g.drawString(initialBoxScore.getTeams()[0].getName()+" "+initialBoxScore.getTeams()[0].getR()+" , "+initialBoxScore.getTeams()[1].getName()+" "+initialBoxScore.getTeams()[1].getR(),
				// 260,140);
				g.setFont(new Font("Arial", Font.PLAIN, 15));
				g.drawImage(team1, BANNER_LOC.x + 48, BANNER_LOC.y + 85, this);
				g.drawImage(team2, BANNER_LOC.x + 215, BANNER_LOC.y + 85, this);
				g.drawString(teamname1 + " "
						+ initialBoxScore.getTeams()[0].getR() + "       "
						+ teamname2 + initialBoxScore.getTeams()[1].getR(),
						BANNER_INFO_LOC.x - 20, BANNER_INFO_LOC.y - 58);

				// Display the BoxScore of the Game
				g.setFont(new Font("Arial", Font.PLAIN, 12));
				displayBoxScore(g, BANNER_INFO_LOC.x - 2,
						BANNER_INFO_LOC.y - 20, 360, 120);

			} else {
				g.setColor(Color.red);
				g.setFont(BANNER_ERROR_FONT);
				g.drawString(ErrorMessage, BANNER_INFO_LOC.x + 40,
						BANNER_INFO_LOC.y - 60);
				g.setFont(BANNER_INFO_FONT);
				g.setColor(BANNER_INFO_COLOR);
			}

			g.drawImage(gameButtons[Math.abs(index - 0)],
					BANNER_INFO_LOC.x - 10, BANNER_INFO_LOC.y + 185, this);
			g.drawImage(playButtons[Math.abs(index - 1)], BANNER_INFO_LOC.x
					+ 70 + playButtons[0].getWidth(this) + y,
					BANNER_INFO_LOC.y + 185, this);
		} else {
			URL url = null;
			url = this.getClass().getResource(BANNER_PIC1);
			m_background = java.awt.Toolkit.getDefaultToolkit().getImage(url);
			g.drawImage(m_background, BANNER_LOC.x, BANNER_LOC.y, this);
			g.setFont(new Font("tiresias", Font.BOLD, 20));
			g.setColor(Color.white);
			g.drawString("Welcome to Sports Stats", BANNER_INFO_LOC.x + 30, 25);
			g.setColor(Color.red);
			g.setFont(BANNER_ERROR_FONT);
			g.drawString(ErrorMessage, BANNER_INFO_LOC.x, BANNER_INFO_LOC.y);
		}
		getToolkit().sync();
	}

	/*
	 * displayBoxScore method is used to build up the BoxScore and display the
	 * box score on the Screen
	 */
	public void displayBoxScore(Graphics g, int x, int y, int width, int height) {
		g.setColor(Color.white);
		BoxScore b = initialBoxScore;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 13; j++) {
				if (j == 0) {
					if (i == 0) {
						g.setColor(Color.black);
						g.drawString(getInningsScore(null, j), x - 6, y
								+ (i * 25) - 20);
					} else {
						g.setColor(Color.black);
						g.drawString(getInningsScore(b.getTeams()[i - 1], j),
								x + 10, y + (i * 25));

					}
				} else {
					if (j == 1) {
						if (i == 0) {
							g.setColor(Color.black);
							g.drawString(getInningsScore(null, j), x + 60, y
									+ (i * 25));
						} else {
							g.setColor(Color.black);
							g.drawString(
									getInningsScore(b.getTeams()[i - 1], j),
									x + 60, y + (i * 25));

						}
					} else if (j == 12) {
						if (i == 0) {
							g.setColor(Color.black);
							g.drawString(getInningsScore(null, j), x + 64
									+ ((j - 1) * 17), y + (i * 25));
						} else {
							g.setColor(Color.black);

							g
									.drawString(getInningsScore(
											b.getTeams()[i - 1], j), x + 64
											+ ((j - 1) * 17), y + (i * 25));

						}
					} else {
						if (i == 0) {
							g.setColor(Color.black);
							g.drawString(getInningsScore(null, j), x + 60
									+ ((j - 1) * 17), y + (i * 25));
						} else {
							g.setColor(Color.black);

							g
									.drawString(getInningsScore(
											b.getTeams()[i - 1], j), x + 60
											+ ((j - 1) * 17), y + (i * 25));

						}
					}
				}
			}
		}
		g.setColor(Color.white);
	}

	/*
	 * Read the Innings score of a team
	 */

	public String getInningsScore(Team t, int i) {
		String res = null;
		if (t != null) {
			switch (i) {
			case 0:
				res = t.getName();
				break;
			case 1:
				res = Integer.toString(t.getOne());
				break;
			case 2:
				res = Integer.toString(t.getTwo());
				break;
			case 3:
				res = Integer.toString(t.getThree());
				break;
			case 4:
				res = Integer.toString(t.getFour());
				break;
			case 5:
				res = Integer.toString(t.getFive());
				break;
			case 6:
				res = Integer.toString(t.getSix());
				break;
			case 7:
				res = Integer.toString(t.getSeven());
				break;
			case 8:
				res = Integer.toString(t.getEight());
				break;
			case 9:
				res = Integer.toString(t.getNine());
				break;
			/*
			 * case 10: res = ""; break;
			 */
			case 10:
				res = "" + t.getR();
				break;
			case 11:
				res = "" + t.getH();
				break;
			case 12:
				res = "" + t.getE();
				break;

			default:
				break;
			}
		} else {
			switch (i) {
			case 0:
				res = "Team Name";
				break;
			case 1:
				res = Integer.toString(i);
				break;
			case 2:
				res = Integer.toString(i);
				break;
			case 3:
				res = Integer.toString(i);
				break;
			case 4:
				res = Integer.toString(i);
				break;
			case 5:
				res = Integer.toString(i);
				break;
			case 6:
				res = Integer.toString(i);
				break;
			case 7:
				res = Integer.toString(i);
				break;
			case 8:
				res = Integer.toString(i);
				break;
			case 9:
				res = Integer.toString(i);
				break;
			/*
			 * case 10: res = ""; break;
			 */
			case 10:
				res = "R";
				break;
			case 11:
				res = "H";
				break;
			case 12:
				res = "E";
				break;

			default:
				break;
			}
		}
		return res;
	}

}
