package com.cts.csap.vo;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class VendorQuotation implements Comparable<VendorQuotation>,Serializable {
	
	private String id;
	@DBRef
	private Vendor vendor;
	private double price;
	
	public VendorQuotation() {
	}
	
	public VendorQuotation(Vendor vendor, double price) {
		super();
		this.vendor = vendor;
		this.price = price;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Vendor getVendor() {
		return vendor;
	}
	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	public int compareTo(VendorQuotation vendorQuotation) {
		return new Double(price).compareTo(vendorQuotation.getPrice());
	}

	@Override
	public String toString() {
		return "VendorQuotation [id=" + id + ", vendor=" + vendor + ", price="
				+ price + "]";
	}

	
	
	

}
