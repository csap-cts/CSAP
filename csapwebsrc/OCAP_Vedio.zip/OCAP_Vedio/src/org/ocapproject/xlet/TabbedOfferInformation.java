package org.ocapproject.xlet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//import javax.swing.BorderFactory;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JPanel;
//import javax.swing.JScrollBar;
//import javax.swing.JScrollPane;
//import javax.swing.JTabbedPane;
//import javax.swing.JTable;
//import javax.swing.ListSelectionModel;
//import javax.swing.UIManager;

public class TabbedOfferInformation extends Frame {

	private static final long serialVersionUID = 1L;

	private static final String TAB_NAMES[] = new String[] { "Exiting Offers", "Product Information", "Help" };

	private static final String COLUMN_NAMES[] = new String[] { "PRODUCT ID", "PRODUCT NAME", "PRODUCT DETAILS", "OFFER DETAILS" };

	public TabbedOfferInformation() {
		UIManager.put("TabbedPane.selected", Color.BLUE);

		JTabbedPane tabbedPane = new JTabbedPane();
		java.awt.
		
		for (int tabIndex = 0; tabIndex < TAB_NAMES.length; tabIndex++) {
			tabbedPane.addTab(TAB_NAMES[tabIndex], this.createPane(TAB_NAMES[tabIndex]));
			tabbedPane.setBackgroundAt(tabIndex, Color.BLUE);
			tabbedPane.setForeground(Color.WHITE);
		}
		tabbedPane.setBorder(BorderFactory.createEmptyBorder());
		this.setBorder(BorderFactory.createCompoundBorder());

		//tabbedPane.setSize(710, 400);
		tabbedPane.setBounds(1, 80, 710, 400);
		tabbedPane.setSelectedIndex(0);
		tabbedPane.setBackground(Color.WHITE);
		
		this.setBounds(1, 20, 710, 400);
		this.add(tabbedPane);
		this.setBackground(Color.WHITE);
		this.setForeground(Color.WHITE);
		this.setOpaque(true);
	}

	private JPanel createPane(final String tabName) {
		JPanel panel = new JPanel();
		panel.setOpaque(true);

		JScrollPane scrollPane = null;

		if (tabName.equals(TAB_NAMES[0])) {
			scrollPane = new JScrollPane(this.getOffersTable());
		} else {
			scrollPane = new JScrollPane();
		}
		
		scrollPane.setBorder(BorderFactory.createEmptyBorder());
		
		scrollPane.setOpaque(true);     
		
		panel.setLayout(new BorderLayout());
		panel.setBorder(BorderFactory.createEmptyBorder());
		panel.setSize(1500, 1500);
		panel.add(scrollPane);
		return panel;
	}

	private JTable getOffersTable() {
		Object rows[][] = {
				{ "COFFEE_DAY_001", "Worst Coffee ever tasted", "Cafe Mocha", "10% Off onb selected coffee, Hurry!!" },
				{ "LEVIS_002", "America Online DataCard", "54 Mbps", "10% Off" },
				{ "BASKINROBIN_007", "LifeStyle Voucher", "Shop on LifeStyle online", "10% Off" },
				{ "EBAY_007", "eBay Voucher", "180 7/8", "20% Off" },
				{ "RELAINCE_FRESH_9871", "EarthWeb", "--------", "Upto 40% Off" },
				{ "RELAINCE_FRESH_9872", "EarthWeb", "--------", "Upto 40% Off" },
				{ "RELAINCE_FRESH_9873", "EarthWeb", "--------", "Upto 40% Off" },	
				{ "RELAINCE_FRESH_9874", "EarthWeb", "--------", "Upto 40% Off" },
				{ "RELAINCE_FRESH_9875", "EarthWeb", "--------", "Upto 40% Off" }
		};


		JTable table = new JTable(rows, COLUMN_NAMES) {
			public boolean isCellEditable(int rowIndex, int vColIndex) {
				return false;
			}
		};		

		table.setRowHeight(50); // ROW HEIGHT
		table.setRowMargin(5);
		table.setFont(new Font("Serif", Font.PLAIN, 13));

		table.setOpaque(true);
		table.setForeground(Color.blue);
		table.setBackground(Color.yellow);

		JScrollBar jScrollBar = new JScrollBar();
		jScrollBar.setVisible(true);
		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setShowGrid(false);
		  
		table.getTableHeader().setResizingAllowed(false);
		table.getTableHeader().setPreferredSize(new Dimension(10, 20));
		
		table.add(jScrollBar);
		return table;
	}

	public static void main(String[] args) {
		JFrame frame = new JFrame("TAB PANE");

		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		frame.getContentPane().add(new TabbedOfferInformation(), BorderLayout.CENTER);
		frame.setVisible(true);
		frame.setSize(1300,760);
	}
}
