package com.cognizant.csap;

import java.util.List;



//a simple delegate to call WS. 
public class CSAPServiceDelegate {

	public String[] getAd() {
		DigitalSubHttpConnWSClient client = new DigitalSubHttpConnWSClient();
		return client.getAdv();
	}

	public List registerInterest(String user, String brand, String productName) {
		DigitalSubHttpConnWSClient client = new DigitalSubHttpConnWSClient();
		return client.registerInterest(user, brand, productName);
	}
}
