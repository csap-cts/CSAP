package com.cts.csap.vo;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Vendor extends CSAPUser {

	private String name;
	private String email;
	private String mobile;
	@DBRef
	private Address address;

	public Vendor() {
	
	}
	
	public Vendor(String name, String email, String mobile, Address address,String csapUserId,
			String csapPassword) {
		super(csapUserId, csapPassword, CSAPUserRoles.VENDOR);
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Vendor [id=" + getUserName() + ", name=" + name + ", email=" + email
				+ ", mobile=" + mobile + ", address=" + address + "]";
	}
	
	
	
}
