package com.cts.csap.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class CustomerInterest implements Serializable{

	private String id;
	@DBRef
	private Product product;
	@DBRef
	private Customer customer;
	private Date requestDate;
	private Map<String, String> facebookComments;
	
	public CustomerInterest() {
	}

	
	public CustomerInterest(Product product, Customer customer,
			Date requestDate, Map<String, String> facebookComments) {
		super();
		this.product = product;
		this.customer = customer;
		this.requestDate = requestDate;
		this.facebookComments = facebookComments;
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public Map<String, String> getFacebookComments() {
		return facebookComments;
	}

	public void setFacebookComments(Map<String, String> facebookComments) {
		this.facebookComments = facebookComments;
	}


	@Override
	public String toString() {
		return "CustomerInterest [id=" + id + ", product=" + product
				+ ", customer=" + customer + ", requestDate=" + requestDate
				+ ", facebookComments=" + facebookComments + "]";
	}
	
	
	
	
}
