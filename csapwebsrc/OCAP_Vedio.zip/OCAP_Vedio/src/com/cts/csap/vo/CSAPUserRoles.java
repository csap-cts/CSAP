package com.cts.csap.vo;

public enum CSAPUserRoles {
	CUSTOMER,
	VENDOR

}
