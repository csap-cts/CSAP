package com.cognizant.csap;

import java.util.Iterator;

import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
//import javax.xml.transform.Source;
//import javax.xml.transform.Transformer;
//import javax.xml.transform.TransformerFactory;
//import javax.xml.transform.stream.StreamResult;

//import org.apache.axis.Message;
//import org.apache.axis.client.Call;
//import org.apache.axis.client.Service;
//import org.apache.axis.constants.Style;
import org.w3c.dom.Node;


/**
 * The Webservice client using Axis 1 for java 1.4.
 */
public class DigitalSubAxisClient {

	
	/*
	public String getAd() {

		String endpoint = "http://csapservices.cloudfoundry.com/CustomerService";
		String ns = "http://service.csap.cts.com/";
		String method = "getRandomProductForOCAP";
		
//		String endpoint = "http://ws.apache.org:5049/axis/services/echo";
//		String ns = "http://soapinterop.org/";
//		String method = "echoString";
		
		String messageStr = 
			"<?xml version=\"1.0\" standalone=\"yes\" ?>" +
			"<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
		               "xmlns:ns1=\"" + ns + "\">" + 
		    "<soap:Body>" + 
		    	"<ns1:" + method + ">" + 
		    	"</ns1:" + method + ">" +
		    "</soap:Body>" +
		    "</soap:Envelope>";
		
		System.out.println(messageStr);
		System.out.println("========");
		
		try {
			Service service = new Service();
			Call call = new Call(service);
			call.setTargetEndpointAddress( new java.net.URL(endpoint) );
			call.setOperationStyle(Style.MESSAGE);
			org.apache.axis.message.SOAPEnvelope envelope = call.invoke(new Message(messageStr));
			System.out.println(envelope.getBody().toString());
			
		}
		catch (Exception mue) {
			mue.printStackTrace();
		} 
//		catch (RemoteException re) {
//			re.printStackTrace();
//		} 
//		catch (SOAPException se) {
//			se.printStackTrace();
//		} 

			
		return null; //TODO .. fix this. dont return null
	}
	*/
	public String getAdv() {
		String operation = "getRandomProductForOCAP";
        String urn = "CustomerService";
        String destination = "http://csapservices.cloudfoundry.com/CustomerService";
        
        try
        {
            // First create the connection
            SOAPConnectionFactory soapConnFactory = SOAPConnectionFactory.newInstance();
            SOAPConnection connection = soapConnFactory.createConnection();

            // Next, create the actual message
            MessageFactory messageFactory = MessageFactory.newInstance();
            SOAPMessage message = messageFactory.createMessage();

            SOAPPart soapPart = message.getSOAPPart();
            SOAPEnvelope envelope = soapPart.getEnvelope();

            // This method demonstrates how to set HTTP and SOAP headers.
            // setOptionalHeaders(message, envelope);

            // Create and populate the body
            SOAPBody body = envelope.getBody();

            // Create the main element and namespace
            SOAPElement bodyElement = body.addChildElement(
                    envelope.createName(operation, "ns1", "urn:"+urn));
            // Add parameters
            //bodyElement.addChildElement("in0").addTextNode(arg1);
            //bodyElement.addChildElement("in1").addTextNode(arg2);

            // Save the message
            message.saveChanges();

            // Check the input
            System.out.println("\nRequest:\n");
            message.writeTo(System.out);
            System.out.println();

            // Send the message and get the reply
            SOAPMessage reply = connection.call(message, destination);

            // Retrieve the result - no error checking is done: BAD!
            soapPart = reply.getSOAPPart();
            envelope = soapPart.getEnvelope();
            body = envelope.getBody();
            
            Iterator iter = body.getChildElements();
            Node resultOuter = ((Node) iter.next()).getFirstChild();
            Node result = resultOuter.getFirstChild();

            System.out.println("result = " + result.getNodeValue());

            // Check the output
            /*
            System.out.println("\nResponse:\n");
            // Create the transformer
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            // Extract the content of the reply
            Source sourceContent = reply.getSOAPPart().getContent();
            // Set the output for the transformation
            StreamResult result1 = new StreamResult(System.out);
            transformer.transform(sourceContent, result1);
            System.out.println();
			*/
            // Close the connection           
            connection.close();
            return result.getNodeValue();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return null; //TODO return actual stuff. 
	}

	
	public static void main(String args[]) {
		new DigitalSubAxisClient().getAdv();
	}
}
