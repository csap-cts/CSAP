package com.cts.csap.vo;

import java.util.Map;

public class VendorOfferings {
	
	private Product product;
	private Map<String, String> facebookComments;
	
	public VendorOfferings() {
	}
	
	public VendorOfferings(Product product, Map<String, String> facebookComments) {
		super();
		this.product = product;
		this.facebookComments = facebookComments;
	}

	public Product getProduct() {
		return product;
	}
	
	public void setProduct(Product product) {
		this.product = product;
	}
	public Map<String, String> getFacebookComments() {
		return facebookComments;
	}
	public void setFacebookComments(Map<String, String> facebookComments) {
		this.facebookComments = facebookComments;
	}

	@Override
	public String toString() {
		return "VendorOfferings [product=" + product + ", facebookComments="
				+ facebookComments + "]";
	}
	
	

}
